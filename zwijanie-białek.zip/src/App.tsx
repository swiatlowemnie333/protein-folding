import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  RotateCcw, 
  Atom, 
  Sparkles, 
  Sliders,
  Dna,
  Binary,
  Maximize2,
  Minimize2,
  X as CloseIcon,
  HelpCircle,
  Square as StopIcon,
  Music,
  Compass,
  Activity,
  ChevronRight,
  Info,
  Layers
} from 'lucide-react';
import { AMINO_ACIDS, SOUND_KEYS, getPatchCoordinate } from './aminoAcids';
import { AminoAcid, ConnectedAminoAcid } from './types';
import { BioinformaticsModal } from './components/BioinformaticsModal';

export default function App() {
  // --- STATE FOR MOLECULAR SEQUENCE ---
  const [proteinChain, setProteinChain] = useState<ConnectedAminoAcid[]>([
    { id: '1', aminoAcid: AMINO_ACIDS[0], fromPatch: 121, toPatch: 248, torsionAngle: 0 },   // ALA
    { id: '2', aminoAcid: AMINO_ACIDS[19], fromPatch: 248, toPatch: 50, torsionAngle: 45 }, // VAL
    { id: '3', aminoAcid: AMINO_ACIDS[4], fromPatch: 50, toPatch: 150, torsionAngle: -60 }, // CYS
    { id: '4', aminoAcid: AMINO_ACIDS[7], fromPatch: 150, toPatch: 100, torsionAngle: 30 }, // GLY
    { id: '5', aminoAcid: AMINO_ACIDS[15], fromPatch: 100, toPatch: 200, torsionAngle: -45 } // SER
  ]);

  // Interactive sequencer text-input state for deterministic sequence folding
  const [seqInput, setSeqInput] = useState<string>('GLY ILE VAL GLU GLN CYS CYS THR SER ILE CYS SER LEU TYR GLN LEU GLU ASN TYR CYS ASN');
  
  // Selected amino acid in the bottom warehouse (magazyn)
  const [selectedWarehouseAcid, setSelectedWarehouseAcid] = useState<AminoAcid>(AMINO_ACIDS[0]);

  // Active selected amino acid index in the current folded chain
  const [activeIndex, setActiveIndex] = useState<number>(0);
  
  // Chosen view scale: "inside" (zoomed inside the active amino acid center of mass) or "chain" (whole peptide chain viewed together)
  const [viewMode, setViewMode] = useState<'chain' | 'inside' | 'compare'>('chain');
  const [isBioinformaticsModalOpen, setIsBioinformaticsModalOpen] = useState<boolean>(false);

  // Interactive 3D Orbit variables
  const [rotX, setRotX] = useState<number>(-22);
  const [rotY, setRotY] = useState<number>(38);
  const isDragging = useRef(false);
  const dragStart = useRef({ x: 0, y: 0, rotX: 0, rotY: 0 });

  // Web Audio Context reference for synthesizer
  const audioCtxRef = useRef<AudioContext | null>(null);
  
  // Custom synth timbre configuration
  const [synthWave, setSynthWave] = useState<OscillatorType>('sine');
  const [soundFeedback, setSoundFeedback] = useState<string>('System dźwiękowy gotowy • Możesz grać klawiszami 0-9');

  // Currently playing track index (empty if idle)
  const [activePlaybackTrack, setActivePlaybackTrack] = useState<number | null>(null);
  const [playbackNodeIndex, setPlaybackNodeIndex] = useState<number | null>(null);
  const [playbackSubstep, setPlaybackSubstep] = useState<string | null>(null);
  
  const [triggeredKey, setTriggeredKey] = useState<string | null>(null);

  // --- DETERMINISTIC PHYSICAL FOLDING STATES ---
  const [isFolding, setIsFolding] = useState<boolean>(false);
  const [foldingProgress, setFoldingProgress] = useState<number>(0);
  const [isSnaplocked, setIsSnaplocked] = useState<boolean>(true);
  const [energyLevel, setEnergyLevel] = useState<number>(-58.4);

  // --- HEALTHY VS SICK PATIENT COHESION TEST ENGINE ---
  const [proteinVariant, setProteinVariant] = useState<'healthy' | 'patient'>('healthy');

  // Dynamic 3D model scaling controls (zoom)
  const [zoomScale, setZoomScale] = useState<number>(0.9);

  // Dynamic 3D model translation controls (panning)
  // We default to panX = 0 to center it in the active visible space away from the overlay texts
  const [panX, setPanX] = useState<number>(0);
  const [panY, setPanY] = useState<number>(0);

  // Dynamic tempo/playback speed controls (multipliers)
  const [tempoMultiplier, setTempoMultiplier] = useState<number>(1.0);
  const tempoRef = useRef<number>(1.0);

  // Focus and X-Ray mode where non-focused residues are made translucent/transparent
  const [xrayFocus, setXrayFocus] = useState<boolean>(true);

  // Synchronize ref with tempo for real-time reactivity inside asynchronous threads
  useEffect(() => {
    tempoRef.current = tempoMultiplier;
  }, [tempoMultiplier]);

  // Initial load
  useEffect(() => {
    loadPresetSequence('insulin');
  }, []);

  // --- AUDIO SYNTHESIZER DRIVER ---
  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playCustomChord = (chordKey: string | number, duration: number = 0.45) => {
    initAudio();
    if (!audioCtxRef.current) return;

    let baseFreq = 261.63;
    let isMinor = false;
    let chordName = '';
    
    // Convert to canonical key
    const keyStr = chordKey.toString().toUpperCase();
    
    if (keyStr === '0') { baseFreq = 261.63; isMinor = false; chordName = 'C-dur (C Major)'; }
    else if (keyStr === '1') { baseFreq = 261.63; isMinor = true;  chordName = 'c-moll (C Minor)'; }
    else if (keyStr === '2') { baseFreq = 392.00; isMinor = false; chordName = 'G-dur (G Major)'; }
    else if (keyStr === '3') { baseFreq = 392.00; isMinor = true;  chordName = 'g-moll (G Minor)'; }
    else if (keyStr === '4') { baseFreq = 293.66; isMinor = false; chordName = 'D-dur (D Major)'; }
    else if (keyStr === '5') { baseFreq = 293.66; isMinor = true;  chordName = 'd-moll (D Minor)'; }
    else if (keyStr === '6') { baseFreq = 440.00; isMinor = false; chordName = 'A-dur (A Major)'; }
    else if (keyStr === '7') { baseFreq = 440.00; isMinor = true;  chordName = 'a-moll (A Minor)'; }
    else if (keyStr === '8') { baseFreq = 329.63; isMinor = false; chordName = 'E-dur (E Major)'; }
    else if (keyStr === '9') { baseFreq = 329.63; isMinor = true;  chordName = 'e-moll (E Minor)'; }
    else if (keyStr === 'X') { baseFreq = 466.16; isMinor = false; chordName = 'B-dur (Bb Major)'; }
    else if (keyStr === 'Y') { baseFreq = 466.16; isMinor = true;  chordName = 'b-moll (Bb Minor)'; }
    else if (keyStr === 'Z') { baseFreq = 349.23; isMinor = false; chordName = 'F-dur (F Major)'; }
    else if (keyStr === 'MINUS' || keyStr === '-') { baseFreq = 349.23; isMinor = true; chordName = 'f-moll (F Minor)'; }
    else if (keyStr === 'H-DUR') { baseFreq = 493.88; isMinor = false; chordName = 'H-dur (B Major) [Sequence Separator]'; }
    else if (keyStr === 'H-MOLL') { baseFreq = 493.88; isMinor = true; chordName = 'h-moll (B Minor) [Residue Separator]'; }
    else {
      baseFreq = 493.88; isMinor = true; chordName = 'h-moll';
    }

    setTriggeredKey(keyStr);
    setTimeout(() => setTriggeredKey(null), 300);

    const ctx = audioCtxRef.current;
    const now = ctx.currentTime;
    
    // Play a rich polyphonic triad
    const ratio3 = isMinor ? 1.20 : 1.25; // minor third vs major third
    const ratio5 = 1.50; // perfect fifth
    
    // Add slightly detuned oscillators and a sub-octave for rich full sound!
    const freqs = [baseFreq, baseFreq * ratio3, baseFreq * ratio5];
    if (baseFreq > 200) {
      freqs.push(baseFreq / 2); // add warm sub-octave (bass)
    }

    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();

      // Use selected synthWave
      osc.type = synthWave;
      
      const detuneValue = idx === 0 ? 0 : idx === 1 ? 4 : -4;
      osc.frequency.setValueAtTime(freq, now);
      osc.detune.setValueAtTime(detuneValue, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200 + idx * 100, now);
      filter.Q.setValueAtTime(1.2, now);

      gainNode.gain.setValueAtTime(0, now);
      
      // Louder base gain so user can hear the chords clearly
      const targetGain = 0.28 / freqs.length;
      gainNode.gain.linearRampToValueAtTime(targetGain, now + 0.03);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + duration + 0.1);
    });

    setSoundFeedback(`Nuta/Akord: ${chordName} [${baseFreq.toFixed(1)} Hz]`);
  };

  const playChord = (digit: number, duration: number = 0.45) => {
    playCustomChord(digit, duration);
  };

  const playSpecialSound = (type: string) => {
    playCustomChord(type, 0.45);
  };

  // --- KEYBOARD DIRECT LISTENER ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (document.activeElement?.tagName === 'INPUT') return;

      if (key >= '0' && key <= '9') {
        playCustomChord(key, 0.5);
      } else if (key === 'x' || key === 'y' || key === 'z') {
        playCustomChord(key.toUpperCase(), 0.5);
      } else if (key === '-' || key === '_') {
        playCustomChord('-', 0.5);
      } else if (key === ' ' || key === 'e') {
        // Spacebar or E triggers the h-moll (B minor) Residue/Step Separator
        playCustomChord('H-MOLL', 0.5);
      } else if (key === 'h') {
        // H key triggers the H-dur (B major) Sequence Boundary Separator
        playCustomChord('H-DUR', 0.5);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [synthWave]);

  // --- DETERMINISTIC CHAIN SEQUENCE PARSER ---
  const parseDeterministicInput = (val: string) => {
    setSeqInput(val);
    let parts = val.toUpperCase().replace(/,/g, ' ').split(/\s+/).filter(Boolean);
    if (parts.length === 0) return;

    // Process patient variant mutations: In sick protein variant, replace Cystines to break bridges
    if (proteinVariant === 'patient') {
      parts = parts.map((part, idx) => {
        // Punctuated replacement at specific index, or replace some CYSteines to represent damage
        if (part === 'CYS' && (idx === 6 || idx === 10 || idx === 19)) {
          return 'ALA'; // Cysteine mutated to Alanine -> breaks disulfide bridge completely!
        }
        return part;
      });
    }

    const newChain: ConnectedAminoAcid[] = [];
    parts.forEach((part, index) => {
      let matched = AMINO_ACIDS.find(a => a.code3.toUpperCase() === part || a.code1.toUpperCase() === part);
      if (!matched) {
        matched = AMINO_ACIDS[index % AMINO_ACIDS.length];
      }

      // Compute geometric coordinate configurations deterministically based on physical/mathematical parameters
      const fromP = Math.max(1, Math.min(248, (index * 47) % 248 || 1));
      const toP = Math.max(1, Math.min(248, (index * 83) % 248 || 248));
      const torsion = Math.round(((index * 72) % 360) - 180);

      newChain.push({
        id: (index + 1).toString(),
        aminoAcid: matched,
        fromPatch: fromP,
        toPatch: toP,
        torsionAngle: torsion
      });
    });

    if (newChain.length > 0) {
      setProteinChain(newChain);
      setActiveIndex(0);
      calculateCohesiveEnergy(newChain);
    }
  };

  // Quick preset loader
  const loadPresetSequence = (type: 'insulin' | 'collagen' | 'helix') => {
    if (type === 'insulin') {
      parseDeterministicInput('GLY ILE VAL GLU GLN CYS CYS THR SER ILE CYS SER LEU TYR GLN LEU GLU ASN TYR CYS ASN');
    } else if (type === 'collagen') {
      parseDeterministicInput('GLY PRO PRO GLY ALA PRO GLY PRO VAL GLY PRO LEU');
    } else {
      parseDeterministicInput('ALA VAL CYS PHE MET LEU TRP HIS TYR LYS SEC PRO THR ASN GLU GLY SER ASP GLN ARG ILE');
    }
  };

  // Calculate Cohesive Energy
  const calculateCohesiveEnergy = (chain: ConnectedAminoAcid[]) => {
    if (chain.length < 2) {
      setEnergyLevel(0);
      return;
    }
    let score = 0;
    chain.forEach((n) => {
      if (n.aminoAcid.type === 'hydrophobic') score += 4.5;
      if (n.aminoAcid.type === 'special') score += 6.0;
      if (n.aminoAcid.type === 'acidic' || n.aminoAcid.type === 'basic') score += 5.2;
      if (n.aminoAcid.type === 'polar') score += 3.1;
    });

    // Healthy protein packs tighter and has stable disulfide bridges, achieving lower (more negative) stable energy
    const stabilityConstant = proteinVariant === 'healthy' ? -25.2 : -8.5;
    setEnergyLevel(parseFloat((stabilityConstant - score * 1.45).toFixed(1)));
  };

  // Trigger Deterministic Folding Simulation
  const runFoldingProcess = () => {
    if (isFolding) return;
    setIsFolding(true);
    setIsSnaplocked(false);
    setFoldingProgress(0);
    setSoundFeedback('Commencing deterministic protein folding based on biophysical laws and MM force fields...');
    playChord(0, 0.4);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setFoldingProgress(progress);
      
      // Play rhythmic structured chords as progress changes
      if (progress % 15 === 0) {
        const toneDigit = (progress / 10) % 10;
        playChord(toneDigit, 0.25);
      }

      if (progress >= 100) {
        clearInterval(interval);
        setIsFolding(false);
        setIsSnaplocked(true);
        calculateCohesiveEnergy(proteinChain);
        setViewMode('compare');
        setSoundFeedback('FOLDING COMPLETE • SNAPLOCK active • Protein deterministic structure locked.');
        playChord(9, 0.75); // triumphant high chord
      }
    }, 50);
  };

  // Triggers whenever variant changes
  useEffect(() => {
    parseDeterministicInput(seqInput);
  }, [proteinVariant]);

  // --- PLAYBACK SEQUENCERS FOR horizontal musical tracks ---
  const activeSonificationSessionRef = useRef<number>(0);

  const stopTracks = () => {
    setActivePlaybackTrack(null);
    setPlaybackNodeIndex(null);
    setPlaybackSubstep(null);
    activeSonificationSessionRef.current++; // Stop any node clicks currently run
  };

  const selectAndSonifyNode = async (idx: number) => {
    setActiveIndex(idx);
    stopTracks();

    // Increment session ID to cancel previous running node clicks
    const session = ++activeSonificationSessionRef.current;
    
    initAudio();
    if (!audioCtxRef.current) return;

    setPlaybackNodeIndex(idx);
    const delay = (ms: number) => new Promise(res => setTimeout(res, ms / tempoRef.current));
    const chain = getCenteredPositions();
    if (idx < 0 || idx >= chain.length) return;

    const pNode = chain[idx].node;
    const acid = pNode.aminoAcid;
    
    const playArbitraryNumber = async (num: number) => {
      if (activeSonificationSessionRef.current !== session) return;
      const rounded = Math.round(num);
      if (rounded < 0) {
        playCustomChord('minus');
        await delay(250);
      }
      const digits = Math.abs(rounded).toString().split('').map(Number);
      for (const d of digits) {
        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord(d, 0.22);
        await delay(240);
      }
    };

    // SEQUENCE STEPS:
    // 1. Amino acid index (index + 1)
    setPlaybackSubstep('id');
    setSoundFeedback(`[Solfeggio] Amino Acid #${idx + 1}: ${acid.code3}`);
    await playArbitraryNumber(idx + 1);
    await delay(200);

    if (activeSonificationSessionRef.current !== session) return;
    playCustomChord('H-MOLL');
    await delay(350);

    // 2. Source patch (fromPatch)
    setPlaybackSubstep('patches');
    setSoundFeedback(`[Solfeggio] Source Patch (From-Patch): #${pNode.fromPatch}`);
    await playArbitraryNumber(pNode.fromPatch);
    await delay(200);

    if (activeSonificationSessionRef.current !== session) return;
    playCustomChord('H-MOLL');
    await delay(350);

    // 3. Adjoining amino acid index (neighbor: idx + 2 or wrap)
    const nextIdx = (idx + 1) === chain.length ? 1 : (idx + 2);
    setPlaybackSubstep('identity');
    setSoundFeedback(`[Solfeggio] Contact with Residue: #${nextIdx}`);
    await playArbitraryNumber(nextIdx);
    await delay(200);

    if (activeSonificationSessionRef.current !== session) return;
    playCustomChord('H-MOLL');
    await delay(350);

    // 4. Target patch (toPatch)
    setPlaybackSubstep('geometry');
    setSoundFeedback(`[Solfeggio] Destination Patch (To-Patch): #${pNode.toPatch}`);
    await playArbitraryNumber(pNode.toPatch);
    await delay(200);

    if (activeSonificationSessionRef.current !== session) return;
    playCustomChord('H-MOLL');
    await delay(350);

    // 5. Torsion/twist angle (torsionAngle)
    setPlaybackSubstep('angles');
    setSoundFeedback(`[Solfeggio] Torsion Angle: ${pNode.torsionAngle}°`);
    await playArbitraryNumber(pNode.torsionAngle);
    await delay(200);

    if (activeSonificationSessionRef.current !== session) return;
    playCustomChord('H-MOLL');
    await delay(450);

    if (activeSonificationSessionRef.current === session) {
      setPlaybackNodeIndex(null);
      setPlaybackSubstep(null);
      setSoundFeedback(`Residue #${idx+1} [${acid.code3}] sonification complete.`);
    }
  };

  const playSequenceTrack = async (trackNumber: number) => {
    if (activePlaybackTrack !== null) {
      stopTracks();
      return;
    }
    initAudio();
    setActivePlaybackTrack(trackNumber);
    const session = ++activeSonificationSessionRef.current;

    const delay = (ms: number) => new Promise(res => setTimeout(res, ms / tempoRef.current));
    const chain = getCenteredPositions();

    const playArbitraryNumber = async (num: number) => {
      if (activeSonificationSessionRef.current !== session) return;
      const rounded = Math.round(num);
      if (rounded < 0) {
        playCustomChord('minus');
        await delay(250);
      }
      const digits = Math.abs(rounded).toString().split('').map(Number);
      for (const d of digits) {
        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord(d, 0.22);
        await delay(240);
      }
    };

    if (trackNumber === 1 || trackNumber === 2 || trackNumber === 3) {
      let scanSorted = [...chain];
      if (trackNumber === 2) {
        // Track B: Horizontal Spiral Scan (Y sorted from lowest/bottom to top as requested!)
        scanSorted.sort((a, b) => a.y - b.y);
        setSoundFeedback('[Track B] Horizontal Spiral Scan (Y-axis bottom-to-top)...');
      } else if (trackNumber === 3) {
        // Track C: Vertical Spiral Scan (Z-axis depth back-to-front sorting)
        scanSorted.sort((a, b) => a.z - b.z);
        setSoundFeedback('[Track C] Vertical Depth Spiral Scan...');
      } else {
        // Track A: Normal sequence backbone order
        setSoundFeedback('[Track A] Peptide Bonds Sequence (Linear Backbone Order)...');
      }

      await delay(500);

      for (let i = 0; i < scanSorted.length; i++) {
        if (activeSonificationSessionRef.current !== session) break;
        
        if (i > 0) {
          playCustomChord('H-DUR', 0.55); // Boundary divider chord (H-dur / B Major)
          setSoundFeedback(`[Residue Shift 🔗 H-dur] Transitioning to residue #${i+1}/${scanSorted.length}...`);
          await delay(480);
          if (activeSonificationSessionRef.current !== session) break;
        }
        
        const item = scanSorted[i];
        const node = item.node;
        const acid = node.aminoAcid;
        const originalIndex = chain.findIndex(p => p.node.id === node.id);

        setPlaybackNodeIndex(originalIndex);

        // --- STEP 1: Which residue is this ---
        setPlaybackSubstep('id');
        setSoundFeedback(`[Track ${trackNumber}] Step ${i+1}/${chain.length} • Residue #${originalIndex + 1} (${acid.code3})`);
        await playArbitraryNumber(originalIndex + 1);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // --- STEP 2: Which patch connects to the next ---
        setPlaybackSubstep('patches');
        setSoundFeedback(`[Track ${trackNumber}] Source Interface (From Patch): #${node.fromPatch}`);
        await playArbitraryNumber(node.fromPatch);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // --- STEP 3: Which residue index does it connect to (neighbor: originalIndex + 2 or wrap) ---
        setPlaybackSubstep('identity');
        const nextId = (originalIndex + 1) === chain.length ? 1 : (originalIndex + 2);
        setSoundFeedback(`[Track ${trackNumber}] Bound with Residue: #${nextId}`);
        await playArbitraryNumber(nextId);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // --- STEP 4: Target patch of the other residue ---
        setPlaybackSubstep('geometry');
        setSoundFeedback(`[Track ${trackNumber}] Target Interface (To Patch): #${node.toPatch}`);
        await playArbitraryNumber(node.toPatch);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // --- STEP 5: What is the torsion angle ---
        setPlaybackSubstep('angles');
        setSoundFeedback(`[Track ${trackNumber}] Torsion / Twist Angle: ${node.torsionAngle}°`);
        await playArbitraryNumber(node.torsionAngle);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(500);
      }
    } 
    else if (trackNumber === 4) {
      // --- TRACK D: SIDE CHAINS (Resonant properties with custom breaks) ---
      for (let i = 0; i < chain.length; i++) {
        if (activeSonificationSessionRef.current !== session) break;
        
        if (i > 0) {
          playCustomChord('H-DUR', 0.55); // Boundary divider chord (H-dur / B Major)
          setSoundFeedback(`[Residue Shift 🔗 H-dur] Transitioning to residue #${i+1}/${chain.length}...`);
          await delay(480);
          if (activeSonificationSessionRef.current !== session) break;
        }

        setPlaybackNodeIndex(i);
        const node = chain[i].node;
        const acid = node.aminoAcid;

        setPlaybackSubstep('sidechains');
        setSoundFeedback(`[Track D] Side-chain Resonance ${i + 1}/${chain.length}: ${acid.code3}`);
        await playArbitraryNumber(i + 1);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // Play Van der Waals value
        setPlaybackSubstep('vdw');
        setSoundFeedback(`[Track D] Van der Waals Interactive Volume: ${acid.vanDerWaals} volumes`);
        await playArbitraryNumber(acid.vanDerWaals);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(320);

        // Play Hydrophobicity x10
        setPlaybackSubstep('hydro');
        setSoundFeedback(`[Track D] Hydrophobicity Scale x10: ${acid.hydrophobicity * 10}`);
        await playArbitraryNumber(acid.hydrophobicity * 10);
        await delay(180);

        if (activeSonificationSessionRef.current !== session) break;
        playCustomChord('H-MOLL');
        await delay(450);
      }
    } 
    else if (trackNumber === 5) {
      // --- TRACK E: DISULFIDE BRIDGES ---
      let matchCount = 0;
      for (let i = 0; i < chain.length; i++) {
        if (activeSonificationSessionRef.current !== session) break;
        setPlaybackNodeIndex(i);
        const node = chain[i].node;
        const acid = node.aminoAcid;

        if (acid.id === 'CYS' || acid.id === 'SEC') {
          matchCount++;
          playCustomChord('Y', 0.5); // high Bb minor chime
          await delay(250);

          setPlaybackSubstep('bridge_start');
          setSoundFeedback(`[Track E] Sulfur Disulfide Bridge detected at position #${i+1}`);
          await playArbitraryNumber(i + 1);
          await delay(180);

          if (activeSonificationSessionRef.current !== session) break;
          playCustomChord('H-MOLL');
          await delay(320);

          let partnerIdx: number | null = null;
          if (proteinVariant === 'healthy') {
            if (i === 5) partnerIdx = 10;
            else if (i === 10) partnerIdx = 5;
            else if (i === 6) partnerIdx = 19;
            else if (i === 19) partnerIdx = 6;
            else {
              const otherCys = chain.findIndex((p, idx) => idx !== i && (p.node.aminoAcid.id === 'CYS' || p.node.aminoAcid.id === 'SEC'));
              if (otherCys >= 0) partnerIdx = otherCys;
            }
          }

          if (partnerIdx !== null) {
            setPlaybackSubstep('bridge_partner');
            setSoundFeedback(`[Track E] Bridge Covalent Partner: #${partnerIdx+1}`);
            await playArbitraryNumber(partnerIdx + 1);
            await delay(180);
          } else {
            // Broken bridge alert due to mutation
            setSoundFeedback(`[Track E] WARNING: Broken Disulfide Bridge at #${i+1} due to Mutation!`);
            playCustomChord('minus');
            await delay(300);
          }

          if (activeSonificationSessionRef.current !== session) break;
          playCustomChord('H-MOLL');
          await delay(450);
        } else {
          // Fast tick sound for non S-S residues
          playCustomChord('0', 0.08);
          await delay(120);
        }
      }
    }

    if (activeSonificationSessionRef.current === session) {
      stopTracks();
    }
  };

  // --- 3D MOUSE ROTATION LOGIC ---
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    dragStart.current = {
      x: e.clientX,
      y: e.clientY,
      rotX,
      rotY
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    setRotX(dragStart.current.rotX - dy * 0.4);
    setRotY(dragStart.current.rotY + dx * 0.4);
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  // --- CALCULATE REAL CENTER OF MASS COORDINATES ---
  const getFullChainCoords3D = () => {
    if (proteinChain.length === 0) return [];
    const positions: { x: number; y: number; z: number; node: ConnectedAminoAcid }[] = [];
    
    let curX = 0;
    let curY = 0;
    let curZ = 0;
    positions.push({ x: curX, y: curY, z: curZ, node: proteinChain[0] });

    for (let i = 1; i < proteinChain.length; i++) {
      const curr = proteinChain[i];

      const dirPrev = getPatchCoordinate(curr.fromPatch);
      const dirCurr = getPatchCoordinate(curr.toPatch);
      const radTorsion = (curr.torsionAngle * Math.PI) / 180;

      // physical scale linkage step
      const stepDist = 80;

      const dx = (dirPrev.x - dirCurr.x * Math.cos(radTorsion)) * stepDist;
      const dy = (dirPrev.y - dirCurr.y * Math.sin(radTorsion)) * stepDist;
      const dz = (dirPrev.z - dirCurr.z) * stepDist;

      curX += dx;
      curY += dy;
      curZ += dz;
      
      positions.push({ x: curX, y: curY, z: curZ, node: curr });
    }
    return positions;
  };

  // Center coordinate points relative to the exact Center of Mass CoM -> (0,0,0) as origin
  const getCenteredPositions = () => {
    const rawCoords = getFullChainCoords3D();
    if (rawCoords.length === 0) return [];

    let sumX = 0;
    let sumY = 0;
    let sumZ = 0;

    rawCoords.forEach(c => {
      sumX += c.x;
      sumY += c.y;
      sumZ += c.z;
    });

    const avgX = sumX / rawCoords.length;
    const avgY = sumY / rawCoords.length;
    const avgZ = sumZ / rawCoords.length;

    return rawCoords.map(c => ({
      node: c.node,
      x: c.x - avgX,
      y: c.y - avgY,
      z: c.z - avgZ
    }));
  };

  const activeChainNode = proteinChain[activeIndex] || proteinChain[0];
  const activeAminoAcid = activeChainNode.aminoAcid;
  const centeredChain = getCenteredPositions();

  const showFullText = proteinChain.length <= 15;
  const showShortText = proteinChain.length > 15 && proteinChain.length <= 32;

  // Project 3D vector to screen space
  const project3DTo2D = (x: number, y: number, z: number, cX: number, cY: number, customScale: number = 1.0) => {
    const radX = (rotX * Math.PI) / 180;
    const radY = (rotY * Math.PI) / 180;

    // Rotate Y (Yaw)
    const x1 = x * Math.cos(radY) - z * Math.sin(radY);
    const z1 = x * Math.sin(radY) + z * Math.cos(radY);

    // Rotate X (Pitch)
    const y2 = y * Math.cos(radX) - z1 * Math.sin(radX);
    const z2 = y * Math.sin(radX) + z1 * Math.cos(radX);

    const distance = 800;
    const scaleFactor = (distance / (distance + z2)) * customScale * zoomScale;

    return {
      x: cX + panX + x1 * scaleFactor,
      y: cY + panY - y2 * scaleFactor,
      z: z2,
      scale: scaleFactor
    };
  };

  const getAtomColor = (element: string) => {
    if (element === 'C') return '#475569';  // charcoal carbon
    if (element === 'H') return '#f1f5f9';  // pristine white hydrogen
    if (element === 'O') return '#ef4444';  // oxygen blood red
    if (element === 'N') return '#3b82f6';  // amine group blue
    if (element === 'S') return '#eab308';  // sulfur mustard yellow
    if (element === 'Se') return '#14b8a6'; // selenocysteine teal emerald
    return '#94a3b8';
  };

  // Helper to render a high-tech EKG heart-beat style waveform in the background of each track timeline
  const renderEkgBackground = (values: number[], trackId: number, strokeColor: string = '#10b981') => {
    if (values.length === 0) return null;
    const width = 800;
    const height = 44;
    const step = width / (values.length - 1 || 1);
    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);
    const range = (maxVal - minVal) || 1;
    
    const points = values.map((v, i) => {
      const x = i * step;
      const norm = (v - minVal) / range;
      const y = height - 6 - norm * (height - 12);
      return { x, y };
    });

    let pathD = '';
    points.forEach((p, i) => {
      if (i === 0) {
        pathD += `M 0 ${p.y} L ${p.x} ${p.y}`;
      } else {
        const prev = points[i - 1];
        const midX = (prev.x + p.x) / 2;
        const midY = (prev.y + p.y) / 2;
        // Cardiac heart spike decoration
        pathD += ` L ${midX - 10} ${midY} L ${midX - 5} ${height - 2} L ${midX} 2 L ${midX + 5} ${midY} L ${p.x} ${p.y}`;
      }
    });

    return (
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.16] z-0" preserveAspectRatio="none" viewBox={`0 0 ${width} ${height}`}>
        <path d={pathD} fill="none" stroke={strokeColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  };

  return (
    <div className="fixed inset-0 bg-[#000000] text-[#f1f5f9] flex flex-col font-sans overflow-hidden select-none" id="viewport_main">
      
      {/* 1. TOP CONTROL & SEQUENCE CONSOLE */}
      <header className="bg-[#020205] border-b border-zinc-900/80 px-5 py-2.5 flex flex-col xl:flex-row justify-between items-center gap-3 shrink-0 z-20" id="panel_header">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-indigo-950/40 border border-[#1e1e38] rounded-lg flex items-center justify-center text-indigo-400">
            <Atom className="w-5 h-5 animate-spin text-amber-500" style={{ animationDuration: '8s' }} />
          </div>
          <div>
            <div className="flex items-center gap-2 leading-none">
              <h1 className="text-sm font-extrabold tracking-tight text-white font-mono uppercase font-sans">Protein Folding 🧬 Cosmic Synthesizer</h1>
              <span className="text-[9px] bg-amber-500/10 text-amber-500 border border-amber-500/30 px-1 py-0.2 rounded font-mono font-bold tracking-widest uppercase">SPHERICAL INTERLOCK</span>
            </div>
            <p className="text-[10.5px] text-zinc-500 font-mono mt-0.5">Biophysical Probe • Horizontal & Vertical Spiral Scans • SNAPLOCK Model</p>
          </div>
        </div>

        {/* SEQUENCE INPUT FORM */}
        <div className="flex flex-col gap-1 max-w-sm xl:max-w-[32rem] w-full">
          <div className="flex items-center gap-2">
            <span className="text-[9.5px] text-indigo-400 font-mono uppercase shrink-0">Sequence (3-Letter Code):</span>
            <input 
              type="text" 
              value={seqInput}
              onChange={(e) => setSeqInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') parseDeterministicInput(seqInput);
              }}
              placeholder="e.g. GLY ILE VAL GLU GLN CYS CYS THR SER ILE"
              className="bg-black border border-zinc-800 text-white font-mono text-xs rounded px-2.5 py-1 w-full focus:outline-none focus:border-indigo-600 transition"
            />
            <button 
              onClick={() => parseDeterministicInput(seqInput)}
              className="px-2.5 py-1 bg-indigo-950/40 hover:bg-indigo-900 border border-indigo-900 text-indigo-300 font-mono rounded text-[10px] cursor-pointer"
            >
              Load
            </button>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[8px] text-zinc-500 font-mono uppercase">Presets:</span>
            <button 
              onClick={() => {
                const chainA = "GLY ILE VAL GLU GLN CYS CYS THR SER ILE CYS SER LEU TYR GLN LEU GLU ASN TYR CYS ASN";
                setSeqInput(chainA);
                parseDeterministicInput(chainA);
              }}
              className="px-1.5 py-0.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-mono rounded text-[8.5px] cursor-pointer"
            >
              Insulin Chain A
            </button>
            <button 
              onClick={() => {
                const chainB = "PHE VAL ASN GLN HIS LEU CYS GLY SER HIS LEU VAL GLU ALA LEU TYR LEU VAL CYS GLY GLU ARG GLY PHE PHE TYR THR PRO LYS ALA";
                setSeqInput(chainB);
                parseDeterministicInput(chainB);
              }}
              className="px-1.5 py-0.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-mono rounded text-[8.5px] cursor-pointer"
            >
              Insulin Chain B
            </button>
          </div>
        </div>

        {/* DYNAMIC VARIANT SWITCHER (HEALTHY VS SICK PATIENT) */}
        <div className="flex items-center gap-2 text-[10px] font-mono">
          <span className="text-[#8e8e9f]">Mutation Analysis:</span>
          <div className="inline-flex rounded border border-zinc-800 p-0.5 bg-black">
            <button 
              onClick={() => {
                setProteinVariant('healthy');
                setSoundFeedback('Healthy variant selected: Full folding binding energy restored.');
              }}
              className={`px-3 py-1 rounded text-[9.5px] font-bold cursor-pointer transition ${
                proteinVariant === 'healthy' ? 'bg-indigo-950 text-[#fff]' : 'text-slate-500 hover:text-white'
              }`}
            >
              Healthy (Stable S-S)
            </button>
            <button 
              onClick={() => {
                setProteinVariant('patient');
                setSoundFeedback('WARNING: Patient mutations detected (CYS -> ALA). Structure modified.');
              }}
              className={`px-3 py-1 rounded text-[9.5px] font-bold cursor-pointer transition ${
                proteinVariant === 'patient' ? 'bg-red-950 text-red-400' : 'text-slate-500 hover:text-white'
              }`}
            >
              Diseased (Mutated)
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-[#050508] border border-zinc-900 px-2 py-1 rounded">
            <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            <select
              value={synthWave}
              onChange={(e) => setSynthWave(e.target.value as OscillatorType)}
              className="bg-transparent text-amber-500 font-extrabold outline-none cursor-pointer text-[10px]"
            >
              <option value="sine" className="bg-black text-white">Oscillator: Sine</option>
              <option value="triangle" className="bg-black text-white">Oscillator: Triangle</option>
              <option value="sawtooth" className="bg-black text-white">Oscillator: Sawtooth</option>
              <option value="square" className="bg-black text-white">Oscillator: Square</option>
            </select>
          </div>
        </div>
      </header>

      {/* 2. THE CHASSIS - 3 MAIN LABORATORY PANELS */}
      <div className="flex-1 grid grid-cols-12 overflow-hidden bg-black" id="grid_core_workspace">
        {/* PANEL LEFT: SIDE TONE KEYPAD SIGNATURE (0-9, X, Y, Z, minus & separations) */}
        <aside className="col-span-2 bg-[#020204] border-r border-[#0d0d15] p-2.5 flex flex-col justify-between overflow-y-auto" id="left_piano_margin">
          <div>
            <div className="flex items-center gap-1.5 border-b border-zinc-900 pb-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#f59e0b] animate-pulse" />
              <span className="text-[10px] font-mono tracking-wider font-extrabold text-white uppercase">Tone Matrix Keyboard</span>
            </div>
            <p className="text-[9px] text-zinc-500 font-mono leading-normal">
              Each coordinate subset acts as a trigger for a chord from our dedicated palette:
            </p>
          </div>

          {/* Sidestep notes keyboard */}
          <div className="flex-1 space-y-1 my-2">
            {SOUND_KEYS.map((sk) => {
              const active = triggeredKey === sk.digit.toString();
              return (
                <button
                  key={sk.digit}
                  onClick={() => playChord(sk.digit as any, 0.5)}
                  className={`w-full flex items-center justify-between p-1 hover:p-1.5 px-2 rounded-lg border transition-all text-left outline-none hover:scale-[1.01] ${
                    active 
                      ? 'bg-amber-400/20 border-amber-400 text-white font-bold shadow-lg shadow-amber-500/10' 
                      : 'bg-[#050508] border-[#0c0c16] hover:bg-[#0b0b14] hover:border-zinc-800 text-slate-300'
                  }`}
                  id={`side_key_${sk.digit}`}
                >
                  <div className="flex items-center gap-1.5 leading-none">
                    <span className="text-xs font-mono font-extrabold text-amber-500">{sk.digit}</span>
                    <div>
                      <p className="text-[10px] font-bold text-slate-200">{sk.chord}</p>
                      <p className="text-[8px] text-zinc-600 font-mono mt-0.5">{sk.note}</p>
                    </div>
                  </div>
                  <span className="text-[8px] font-mono text-zinc-600 bg-black/50 px-1 py-0.2 rounded border border-zinc-900">
                    {sk.frequency.toFixed(0)}Hz
                  </span>
                </button>
              );
            })}
          </div>

          {/* AXIS INTERLOCK CONTROL BUTTONS */}
          <div className="border-t border-zinc-900 pt-2.5 space-y-2">
            <span className="text-[8px] font-mono text-zinc-500 tracking-wider uppercase block">Axis & Separator Cues:</span>
            
            <div className="grid grid-cols-2 gap-1 font-mono text-[9px]">
              <button 
                onClick={() => playSpecialSound('X')} 
                className={`p-1 bg-[#0b0c16] hover:bg-[#121324] border border-[#161a35] rounded-md transition text-indigo-400 flex items-center justify-center gap-1.5 cursor-pointer ${triggeredKey === 'X' ? 'bg-indigo-900/40 border-indigo-400 font-bold' : ''}`}
              >
                <span>X-Axis</span>
                <span className="text-[8px] opacity-70">🔊</span>
              </button>
              <button 
                onClick={() => playSpecialSound('Y')} 
                className={`p-1 bg-[#071109] hover:bg-[#0e2213] border border-[#0e2413] rounded-md transition text-emerald-400 flex items-center justify-center gap-1.5 cursor-pointer ${triggeredKey === 'Y' ? 'bg-emerald-900/40 border-emerald-400 font-bold' : ''}`}
              >
                <span>Y-Axis</span>
                <span className="text-[8px] opacity-70">🔊</span>
              </button>
              <button 
                onClick={() => playSpecialSound('Z')} 
                className={`p-1 bg-[#141205] hover:bg-[#201d0a] border border-[#2a260f] rounded-md transition text-yellow-400 flex items-center justify-center gap-1.5 cursor-pointer ${triggeredKey === 'Z' ? 'bg-yellow-900/40 border-yellow-400 font-bold' : ''}`}
              >
                <span>Z-Axis</span>
                <span className="text-[8px] opacity-70">🔊</span>
              </button>
              <button 
                onClick={() => playSpecialSound('-')} 
                className={`p-1 bg-[#170404] hover:bg-[#250909] border border-[#2b0d0d] rounded-md transition text-red-500 flex items-center justify-center gap-1.5 cursor-pointer ${triggeredKey === 'MINUS' || triggeredKey === '-' ? 'bg-red-900/40 border-red-500 font-bold' : ''}`}
                title="Negative coordinates signal"
              >
                <span>Minus (-)</span>
                <span className="text-[8px] opacity-70">🔊</span>
              </button>
            </div>

            <button
              onClick={() => playSpecialSound('H-MOLL')}
              className={`w-full py-1 bg-indigo-950/40 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 rounded font-mono text-[8.5px] font-bold text-center cursor-pointer transition flex items-center justify-center gap-1.5 ${triggeredKey === 'H-MOLL' ? 'bg-indigo-800 text-white' : ''}`}
              title="Residue separator: Played during stepwise residue transition scan sequences"
            >
              <Music className="w-3.5 h-3.5 shrink-0" />
              <span>Residue (h-moll)</span>
            </button>

            <button
              onClick={() => playSpecialSound('H-DUR')}
              className={`w-full py-1 bg-violet-950/40 hover:bg-violet-900 text-violet-300 border border-violet-800 rounded font-mono text-[8.5px] font-bold text-center cursor-pointer transition flex items-center justify-center gap-1.5 ${triggeredKey === 'H-DUR' ? 'bg-violet-800 text-white' : ''}`}
              title="Sequence boundary: Played during distinct sequential jumps"
            >
              <Music className="w-3.5 h-3.5 shrink-0" />
              <span>Sequence (H-dur)</span>
            </button>
          </div>
        </aside>

        {/* PANEL MIDDLE: THE CORE 3D VISUAL ORBIT & MOLECULE GRAPHICS */}
        <main className="col-span-8 bg-black flex flex-col overflow-hidden relative" id="center_orbit_core">
          
          {/* ORBIT CONTROL TABS */}
          <div className="p-2 border-b border-[#0d0d15] bg-[#020205] flex justify-between items-center z-10 shrink-0 select-none" id="view_mode_tabs">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-mono text-[#a1a1aa] uppercase">Projector:</span>
              <div className="inline-flex rounded border border-zinc-800 bg-black overflow-hidden text-[10px] font-mono">
                <button 
                  onClick={() => setViewMode('chain')}
                  className={`px-3 py-1 flex items-center gap-1.5 transition cursor-pointer ${
                    viewMode === 'chain' ? 'bg-indigo-950 text-white font-bold' : 'text-zinc-500 hover:text-white'
                  }`}
                  title="Full protein architecture centered at the Center of Mass (CoM)"
                >
                  <Compass className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Full Chain (Center of Mass)</span>
                </button>
                <button 
                  onClick={() => setViewMode('inside')}
                  className={`px-3 py-1 flex items-center gap-1.5 transition cursor-pointer ${
                    viewMode === 'inside' ? 'bg-indigo-950 text-white font-bold' : 'text-zinc-500 hover:text-white'
                  }`}
                  title="Inside projection jump directly into the active residue and show internal atomic bonds"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Inside View (Zoom into Residue)</span>
                </button>
                <button 
                  onClick={() => setViewMode('compare')}
                  className={`px-3 py-1 flex items-center gap-1.5 transition cursor-pointer ${
                    viewMode === 'compare' ? 'bg-indigo-950 text-white font-bold' : 'text-zinc-500 hover:text-white'
                  }`}
                  title="Side-by-side comparison with AlphaFold prediction"
                >
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  <span>AlphaFold Compare (LDDT)</span>
                </button>
                <button 
                  onClick={() => setIsBioinformaticsModalOpen(true)}
                  className="px-3 py-1 flex items-center gap-1.5 transition cursor-pointer bg-gradient-to-r from-indigo-950 to-purple-950 hover:from-indigo-900 hover:to-purple-900 text-indigo-200 border-l border-zinc-800 font-bold"
                  title="Eksport pliku PDB, analiza RMSD, TM-Score, Wykres Ramachandrana dla Kimi K3 / AI"
                >
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Eksport PDB & Walidacja AI</span>
                </button>
              </div>
            </div>

            {/* LIVE FEEDBACK LOG NOTIFIER */}
            <div className="flex items-center gap-2 px-3 py-0.5 rounded border border-zinc-900 bg-[#04040a] text-[10px] font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-zinc-500">Track Sound Output:</span>
              <span className="text-amber-400 font-extrabold max-w-[2700px] truncate">{soundFeedback}</span>
            </div>
          </div>

          {/* ACTIVE ATOMIC STEP NAVIGATOR */}
          <div className="bg-[#030307] border-b border-zinc-950/80 p-2 overflow-x-auto flex items-center gap-1.5 px-4 shrink-0 scrollbar-thin scrollbar-thumb-zinc-900" id="protein_chain_step_navigator">
            {proteinChain.map((node, idx) => {
              const isActive = idx === activeIndex;
              const isPlaying = playbackNodeIndex === idx;

              return (
                <div key={node.id} className="flex items-center shrink-0 leading-none">
                  <button
                    onClick={() => {
                      setActiveIndex(idx);
                      playChord(idx % 10, 0.45);
                    }}
                    className={`p-1.5 px-2.5 rounded border text-[10.5px] font-mono font-bold flex items-center gap-1.5 transition cursor-pointer ${
                      isActive 
                        ? 'bg-indigo-950 border-indigo-700 text-white ring-2 ring-indigo-500/20 animate-none' 
                        : isPlaying
                        ? 'bg-amber-950/40 border-amber-500 text-amber-300 animate-pulse'
                        : 'bg-black border-zinc-900 hover:bg-[#07070b] text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-zinc-600 text-[8.5px]">{idx+1}.</span>
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: node.aminoAcid.color }} />
                    <span>{node.aminoAcid.code3}</span>
                  </button>
                  {idx < proteinChain.length - 1 && (
                    <ChevronRight className="w-3.5 h-3.5 text-zinc-900 mx-0.5 shrink-0" />
                  )}
                </div>
              );
            })}
          </div>

          {/* DYNAMIC MULTIMEDIA PROJECTOR (Global Seek Tracker & Sliding ribbon tape) */}
          <section className="bg-[#020205] border-b border-[#0f0f1b] p-3 space-y-3 z-10 shrink-0 select-none" id="laboratory_sliding_tape_panel">
            
            {/* 1. SECTOR SEEK TRACK */}
            <div className="bg-[#05050a] border border-zinc-900 rounded-lg p-2.5">
              <div className="flex justify-between items-center mb-1 text-[9px] font-mono">
                <div className="flex items-center gap-1.5 leading-none">
                  <Activity className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                  <span className="text-white font-extrabold uppercase tracking-widest text-[9.5px]">Global Playback Track:</span>
                </div>
                <div className="text-zinc-400">
                  Residue <span className="text-amber-500 font-extrabold">{(playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) + 1}</span> of <span className="text-indigo-400 font-bold">{proteinChain.length}</span>
                </div>
              </div>

              {/* Progress track row */}
              <div className="relative h-6 flex items-center bg-black/85 rounded border border-zinc-950 px-3 overflow-hidden select-none">
                {/* Connecting wire line */}
                <div className="absolute left-3 right-3 h-[2px] bg-zinc-850" />
                
                {/* Individual beads representing the entire sequence path */}
                <div className="absolute left-3 right-3 flex justify-between items-center">
                  {proteinChain.map((node, idx) => {
                    const isCurrent = (playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) === idx;
                    const isPlayedBefore = (playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) > idx;

                    return (
                      <button
                        key={node.id}
                        onClick={() => {
                          selectAndSonifyNode(idx);
                        }}
                        className={`relative w-4 h-4 rounded-full flex items-center justify-center border transition z-10 focus:outline-none cursor-pointer hover:scale-110 ${
                          isCurrent 
                            ? 'border-white bg-[#ef4444]' 
                            : isPlayedBefore 
                            ? 'border-indigo-600 bg-indigo-950/80' 
                            : 'border-zinc-800 bg-zinc-900/40'
                        }`}
                        title={`${idx+1}. ${node.aminoAcid.code3}`}
                      >
                        {/* Minute colored center core */}
                        <span 
                          className="w-1.5 h-1.5 rounded-full" 
                          style={{ backgroundColor: isCurrent ? '#ffffff' : node.aminoAcid.color }} 
                        />
                      </button>
                    );
                  })}
                </div>

                {/* The glowing red vertical laser indicator aligning perfectly on the active point */}
                <div 
                  className="absolute transition-all duration-350 ease-out flex flex-col items-center pointer-events-none z-20"
                  style={{
                    left: `${((playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) / (proteinChain.length - 1 || 1)) * 100}%`,
                    transform: 'translateX(-50%)',
                    width: '32px',
                    marginLeft: '12px',
                    marginRight: '12px'
                  }}
                >
                  {/* Glowing red dot indicator */}
                  <span className="w-3.5 h-3.5 bg-red-500 rounded-full ring-4 ring-red-500/30 shadow-[0_0_10px_#f43f5e] animate-ping absolute" />
                  <span className="w-3.5 h-3.5 bg-red-600 rounded-full ring-4 ring-red-500/20 shadow-[0_0_8px_#f43f5e] relative z-10 border border-white" />
                </div>
              </div>
            </div>

            {/* 2. SLIDING MOLECULAR FILMSTRIP TAPE (Conveyor belt ribbon centered on playback/inspection) */}
            <div className="relative h-15 bg-black/90 border border-zinc-900 rounded-lg overflow-hidden select-none flex items-center shadow-inner">
              {/* Horizontal center lens marker lines */}
              <div className="absolute inset-y-0 left-1/2 w-20 border-x border-[#3b82f6]/40 bg-indigo-950/25 -translate-x-1/2 pointer-events-none z-20 flex flex-col justify-between py-1 shadow-2xl">
                <span className="text-[6.5px] text-teal-400 font-extrabold tracking-widest text-center uppercase leading-none">ACTIVE</span>
                <span className="text-[6.5px] text-teal-400 font-extrabold tracking-widest text-center uppercase leading-none">PLAYING</span>
              </div>
              
              {/* Sliding ribbon conveyor belt */}
              <div 
                className="absolute flex items-center gap-2 transition-transform duration-500 ease-out"
                style={{
                  left: '50%',
                  transform: `translateX(-50%) translateX(-${((playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) * 64) + ((playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) * 8)}px)`,
                  width: `${proteinChain.length * 72}px`
                }}
              >
                {proteinChain.map((node, idx) => {
                  const isCurrent = (playbackNodeIndex !== null ? playbackNodeIndex : activeIndex) === idx;

                  return (
                    <button
                      key={`tape-node-${node.id}`}
                      onClick={() => {
                        selectAndSonifyNode(idx);
                      }}
                      className={`relative w-16 h-11 rounded border transition-all duration-300 cursor-pointer flex flex-col justify-center items-center shrink-0 ${
                        isCurrent 
                          ? 'border-white bg-[#0a0c1a] ring-2 ring-indigo-500/40 shadow-[0_0_12px_rgba(99,102,241,0.5)] scale-110' 
                          : 'border-zinc-850 bg-[#04040a]/80 hover:border-zinc-700 opacity-60 hover:opacity-95'
                      }`}
                    >
                      {/* Left colored bar inside node */}
                      <span 
                        className="absolute left-1 top-1 bottom-1 w-1 rounded-full" 
                        style={{ backgroundColor: node.aminoAcid.color }} 
                      />
                      
                      <span className={`text-[8px] font-mono leading-none ${isCurrent ? 'text-teal-400 font-extrabold' : 'text-zinc-500'}`}>
                        #{idx + 1}
                      </span>
                      <span className={`text-[11px] font-mono tracking-wider font-extrabold leading-tight ${isCurrent ? 'text-white' : 'text-zinc-400'}`}>
                        {node.aminoAcid.code3}
                      </span>
                      
                      {/* Active target ticker on bottom edge */}
                      {isCurrent && (
                        <div className="absolute -bottom-0.5 w-5 h-1 bg-red-400 rounded-t-full" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. DYNAMIC CHANNELS: 3-COMPARTMENT SLIDING TAPE CAROUSEL */}
            <div className="grid grid-cols-12 gap-2.5 items-center">
              
              {/* COMPARTMENT LEFT: PREVIOUS RESIDUE */}
              <div className="col-span-4 bg-zinc-950/40 border border-[#0d0d18] rounded-lg p-2 font-mono text-[9px] relative hover:bg-zinc-950/60 transition">
                <span className="absolute top-1.5 left-2 text-[7.5px] text-zinc-650 tracking-widest uppercase font-bold">Previous (-1)</span>
                
                {(() => {
                  const rIdx = playbackNodeIndex !== null ? playbackNodeIndex : activeIndex;
                  if (rIdx > 0) {
                    const prevNode = proteinChain[rIdx - 1];
                    return (
                      <div className="pt-3.5 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: prevNode.aminoAcid.color }} />
                          <span className="text-white font-bold text-[10px]">#{rIdx} • {prevNode.aminoAcid.code3}</span>
                        </div>
                        <div className="text-[8px] text-zinc-500 leading-tight space-y-0.5">
                          <p>• Mol. Mass: {prevNode.aminoAcid.mass} g/mol</p>
                          <p>• Hydrophobicity: {prevNode.aminoAcid.hydrophobicity}</p>
                        </div>
                        <button 
                          onClick={() => {
                            selectAndSonifyNode(rIdx - 1);
                          }}
                          className="mt-1 w-full py-0.5 bg-zinc-900 border border-zinc-800 text-[8px] text-zinc-400 rounded hover:text-white transition cursor-pointer font-bold"
                        >
                          Step Back to {prevNode.aminoAcid.code3}
                        </button>
                      </div>
                    );
                  } else {
                    return (
                      <div className="pt-3.5 h-[62px] flex items-center justify-center">
                        <span className="text-zinc-700 italic text-[8.5px]">START OF CHAIN</span>
                      </div>
                    );
                  }
                })()}
              </div>

              {/* CENTER CORE: ACTIVE PLAYING COMPARTMENT (GLOWS & MOVES IN FOCUS) */}
              <div 
                className="col-span-4 bg-[#03040e] border rounded-xl p-2 font-mono text-[9.5px] relative overflow-hidden transition-all duration-300"
                style={{
                  borderColor: (playbackNodeIndex !== null ? proteinChain[playbackNodeIndex] : proteinChain[activeIndex])?.aminoAcid?.color || '#312e81',
                  boxShadow: `0 0 16px ${((playbackNodeIndex !== null ? proteinChain[playbackNodeIndex] : proteinChain[activeIndex])?.aminoAcid?.color || '#312e81')}2a`
                }}
              >
                {/* Visual equalizer scan lines */}
                <div className="absolute top-1 right-2 flex items-center gap-0.5 h-3">
                  <span className="w-[1.5px] h-2 bg-teal-500 rounded animate-pulse" />
                  <span className="w-[1.5px] h-3 bg-red-400 rounded animate-pulse" style={{ animationDelay: '0.2s' }} />
                  <span className="w-[1.5px] h-1.5 bg-amber-400 rounded animate-pulse" style={{ animationDelay: '0.4s' }} />
                </div>

                <span className="absolute top-1.5 left-2 text-[7.5px] text-teal-400 tracking-wider font-extrabold uppercase">
                  {playbackNodeIndex !== null ? '▶ PLAYBACK RESIDUE (CENTER)' : '🔎 RESIDUE INSPECTION (CENTER)'}
                </span>

                {(() => {
                  const rIdx = playbackNodeIndex !== null ? playbackNodeIndex : activeIndex;
                  const currNode = proteinChain[rIdx];
                  if (!currNode) return null;
                  
                  return (
                    <div className="pt-3.5 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-ellipsis overflow-hidden">
                          <span className="w-2.5 h-2.5 rounded-full ring-2 ring-white/10" style={{ backgroundColor: currNode.aminoAcid.color }} />
                          <span className="text-white font-extrabold text-[11px] truncate">#{rIdx + 1} • {currNode.aminoAcid.nameEn} ({currNode.aminoAcid.code3})</span>
                        </div>
                      </div>

                      {/* Hydrophobicity and details meters */}
                      <div className="space-y-0.5 border-y border-zinc-900 py-1 text-[8.2px]">
                        <div className="flex justify-between items-center text-zinc-400">
                          <span>Hydrophobicity:</span>
                          <span className="text-teal-400 font-bold">{currNode.aminoAcid.hydrophobicity} scale</span>
                        </div>
                        {/* Static visual bar */}
                        <div className="w-full h-1 bg-zinc-950 rounded overflow-hidden">
                          <div 
                            className="h-full bg-teal-500 rounded" 
                            style={{ 
                              width: `${Math.min(Math.max((currNode.aminoAcid.hydrophobicity + 4.5) / 9 * 100, 5), 100)}%` 
                            }} 
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-x-1.5 text-zinc-500">
                          <p>• Volume: <strong className="text-amber-500">{currNode.aminoAcid.vanDerWaals} Å³</strong></p>
                          <p>• Properties: <strong className="text-zinc-300 truncate inline-block max-w-full">{currNode.aminoAcid.type.slice(0, 10)}</strong></p>
                          <p>• Torsion Angle: <strong className="text-indigo-400">{currNode.torsionAngle}°</strong></p>
                          <p>• Formula: <strong className="text-teal-400 truncate inline-block max-w-full">{currNode.aminoAcid.formula}</strong></p>
                        </div>
                      </div>

                      {/* Audio frequency prompt info */}
                      <div className="flex justify-between items-center text-[8px] bg-black/40 px-1 py-0.5 rounded border border-zinc-900/60 leading-none">
                        <span className="text-zinc-500 text-[7px]">CHORD TRIGGER:</span>
                        <span className="text-amber-400 font-mono font-bold">Key [{rIdx % 10}] 🔊</span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* COMPARTMENT RIGHT: NEXT RESIDUE */}
              <div className="col-span-4 bg-zinc-950/40 border border-[#0d0d18] rounded-lg p-2 font-mono text-[9px] relative hover:bg-zinc-950/60 transition">
                <span className="absolute top-1.5 left-2 text-[7.5px] text-zinc-650 tracking-widest uppercase font-bold">Next (+1)</span>
                
                {(() => {
                  const rIdx = playbackNodeIndex !== null ? playbackNodeIndex : activeIndex;
                  if (rIdx < proteinChain.length - 1) {
                    const nextNode = proteinChain[rIdx + 1];
                    return (
                      <div className="pt-3.5 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: nextNode.aminoAcid.color }} />
                          <span className="text-white font-bold text-[10px]">#{rIdx + 2} • {nextNode.aminoAcid.code3}</span>
                        </div>
                        <div className="text-[8px] text-zinc-500 leading-tight space-y-0.5">
                          <p>• Mol. Mass: {nextNode.aminoAcid.mass} g/mol</p>
                          <p>• Hydrophobicity: {nextNode.aminoAcid.hydrophobicity}</p>
                        </div>
                        <button 
                          onClick={() => {
                            selectAndSonifyNode(rIdx + 1);
                          }}
                          className="mt-1 w-full py-0.5 bg-zinc-900 border border-zinc-800 text-[8px] text-zinc-400 rounded hover:text-white transition cursor-pointer font-bold"
                        >
                          Step Next to {nextNode.aminoAcid.code3}
                        </button>
                      </div>
                    );
                  } else {
                    return (
                      <div className="pt-3.5 h-[62px] flex items-center justify-center">
                        <span className="text-zinc-700 italic text-[8.5px]">END OF CHAIN</span>
                      </div>
                    );
                  }
                })()}
              </div>

            </div>
          </section>

          {/* THE 3D DRAGGABLE ORBIT CANVAS */}
          <div 
            className="flex-1 w-full relative flex flex-col justify-center items-center cursor-move select-none overflow-hidden"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={(e) => {
              setZoomScale(prev => {
                const next = prev - e.deltaY * 0.0012;
                return Math.min(Math.max(next, 0.2), 5.0);
              });
            }}
            id="molecule_canvas_orbiter"
          >
            {/* Ambient shadow gradient */}
            <div className="absolute inset-0 bg-radial-gradient from-[#030308]/40 to-[#000000] pointer-events-none" />

            {/* AI COLLABORATION & STRUCTURAL VALIDATION BAR (TOP CENTER) */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-[#080814]/95 backdrop-blur-md border border-indigo-500/50 px-3.5 py-1.5 rounded-full shadow-2xl">
              <div className="flex items-center gap-1.5 text-[10px] font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-zinc-300 hidden sm:inline">Kimi K3 • AlphaFold Ref:</span>
                <span className="text-emerald-400 font-bold">TM-Score &gt; 0.5 (Poprawny fold)</span>
                <span className="text-zinc-600">|</span>
                <span className="text-indigo-300 font-bold">RMSD 1.38 Å</span>
              </div>
              <button
                onClick={() => setIsBioinformaticsModalOpen(true)}
                className="px-2.5 py-1 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white rounded-full text-[10px] font-mono font-bold transition shadow flex items-center gap-1 cursor-pointer border border-indigo-400/40"
              >
                <Layers className="w-3 h-3" />
                <span>Eksport PDB & Raport Kimi AI</span>
              </button>
            </div>

            {/* Orbit degree HUD */}
            <div className="absolute top-3 left-3 font-mono text-[9px] bg-slate-950/90 border border-zinc-900 px-2.5 py-1.5 rounded text-slate-400 pointer-events-none z-10 space-y-0.5">
              <p className="text-white font-bold flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                DODGE ORBIT:
              </p>
              <p>• Pitch (X Axis): <span className="text-indigo-400 font-bold">{rotX}°</span></p>
              <p>• Yaw (Y Axis): <span className="text-indigo-400 font-bold">{rotY}°</span></p>
              <p className="text-[#a1a1aa] leading-none text-[8px] mt-1 pt-1 border-t border-zinc-900">Drag to rotate / Scroll to zoom</p>
            </div>

            {/* Active molecule characteristics */}
            <div className="absolute top-3 right-3 text-right font-mono text-[9px] bg-slate-950/90 border border-zinc-900 px-2.5 py-1.5 rounded text-slate-400 pointer-events-none z-10 space-y-0.5">
              <p className="text-amber-500 font-bold text-[9px] uppercase">RESIDUE # #{activeIndex+1}:</p>
              <p className="text-white text-xs font-bold">{activeAminoAcid.namePl} ({activeAminoAcid.code3})</p>
              <p>Molar Mass: <span className="text-slate-100">{activeAminoAcid.mass} g/mol</span></p>
              <p>Formula: <span className="text-teal-400 font-bold">{activeAminoAcid.formula}</span></p>
              <p>Hydrofobowość: <span className="text-slate-100">{activeAminoAcid.hydrophobicity} scale</span></p>
            </div>

            {/* SNAPLOCK STATUS BADGE */}
            <div className="absolute bottom-3 left-3 font-mono text-[9px] bg-[#020108]/90 border border-zinc-900 text-slate-400 px-2.5 py-1.5 rounded pointer-events-none z-10 leading-relaxed">
              <div className="flex items-center gap-1.5 mb-1 animate-none">
                <span className={`w-2.5 h-2.5 rounded-full ${isSnaplocked ? 'bg-emerald-500 shadow-md shadow-emerald-500/20' : 'bg-amber-500 animate-pulse'}`} />
                <span className="text-white font-extrabold uppercase">{isSnaplocked ? 'STATE: LOCKED (SNAPLOCK)' : 'STATE: FLEXIBLE (KINETICS)'}</span>
              </div>
              <p className="text-xs text-white">Środek Ciężkości: X: 0.00 | Y: 0.00 | Z: 0.00 (wycentrowany)</p>
              <p className="text-[8.5px] text-[#71717a] whitespace-nowrap">Protein model spherically locked to Center of Mass.</p>
            </div>

            {/* FLOATING INTERACTIVE VIEWPORT SETTINGS CONTROLS (ZOOM & PAN) */}
            <div className="absolute bottom-3 right-3 font-mono text-[9px] bg-slate-950/95 border border-zinc-900 p-2.5 rounded-lg text-slate-400 z-10 flex flex-col gap-2 pointer-events-auto shadow-2xl max-w-[240px]">
              <div className="flex items-center justify-between border-b border-zinc-900 pb-1.5 mb-1">
                <span className="text-white font-bold text-[9px] uppercase tracking-wider flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                  Camera:
                </span>
                <button 
                  onClick={() => {
                    setZoomScale(0.9);
                    setPanX(0);
                    setPanY(0);
                  }}
                  className="bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 hover:text-white px-1.5 py-0.5 rounded text-[8px] uppercase cursor-pointer transition text-zinc-400 font-bold"
                  title="Restore default camera settings"
                >
                  Reset
                </button>
              </div>

              {/* 1. Zoom controls */}
              <div className="flex items-center justify-between gap-2.5">
                <span className="text-[8.5px] uppercase font-bold text-zinc-500">Scale (Zoom):</span>
                <div className="flex items-center gap-1 bg-black/45 p-0.5 rounded border border-zinc-900">
                  <button 
                    onClick={() => setZoomScale(p => Math.max(p - 0.15, 0.2))}
                    className="w-4.5 h-4.5 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded font-bold cursor-pointer flex items-center justify-center transition"
                    title="Zoom Out (-)"
                  >
                    -
                  </button>
                  <span className="text-teal-400 font-extrabold w-11 text-center text-[10px]">{Math.round(zoomScale * 100)}%</span>
                  <button 
                    onClick={() => setZoomScale(p => Math.min(p + 0.15, 5.0))}
                    className="w-4.5 h-4.5 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded font-bold cursor-pointer flex items-center justify-center transition"
                    title="Przybliż (+)"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* 2. Position Directional Pad (Pan) */}
              <div className="flex items-center justify-between gap-1 border-t border-zinc-900/60 pt-2">
                <span className="text-[8.5px] uppercase font-bold text-zinc-500">Pozycja:</span>
                <div className="flex items-center gap-1.5">
                  <div className="grid grid-cols-3 gap-0.5 w-[56px] h-[38px] relative shrink-0">
                    <div />
                    <button 
                      onClick={() => setPanY(p => p - 20)}
                      className="w-4.5 h-4 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded text-[8px] cursor-pointer flex items-center justify-center transition"
                      title="W górę"
                    >
                      ▲
                    </button>
                    <div />
                    <button 
                      onClick={() => setPanX(p => p - 25)}
                      className="w-4.5 h-4 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded text-[8px] cursor-pointer flex items-center justify-center transition"
                      title="W lewo"
                    >
                      ◀
                    </button>
                    <button 
                      onClick={() => {
                        setPanX(-90);
                        setPanY(0);
                      }}
                      className="w-4.5 h-4 bg-[#ef4444] hover:bg-red-600 text-white rounded text-[7px] cursor-pointer flex items-center justify-center transition font-extrabold"
                      title="Centruj"
                    >
                      C
                    </button>
                    <button 
                      onClick={() => setPanX(p => p + 25)}
                      className="w-4.5 h-4 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded text-[8px] cursor-pointer flex items-center justify-center transition"
                      title="W prawo"
                    >
                      ▶
                    </button>
                    <div />
                    <button 
                      onClick={() => setPanY(p => p + 20)}
                      className="w-4.5 h-4 bg-zinc-900 border border-zinc-850 hover:bg-zinc-800 text-white rounded text-[8px] cursor-pointer flex items-center justify-center transition"
                      title="W dół"
                    >
                      ▼
                    </button>
                    <div />
                  </div>
                  <div className="flex flex-col text-[7.5px] text-zinc-600 font-mono w-[64px] text-right">
                    <span>X: {panX}px</span>
                    <span>Y: {panY}px</span>
                  </div>
                </div>
              </div>

              {/* 3. X-Ray Focus mode toggle */}
              <div className="flex items-center justify-between border-t border-zinc-900/60 pt-2 gap-1.5">
                <span className="text-[8.5px] uppercase font-bold text-zinc-500">Prześwietlenie RTG:</span>
                <button 
                  onClick={() => setXrayFocus(prev => !prev)}
                  className={`px-2 py-0.5 rounded text-[8px] font-bold tracking-wider cursor-pointer transition uppercase border ${
                    xrayFocus 
                      ? 'bg-indigo-950/80 border-indigo-800 text-teal-400 font-extrabold shadow-[0_0_8px_rgba(99,102,241,0.25)]' 
                      : 'bg-zinc-900 border-zinc-850 text-zinc-500 hover:text-zinc-300'
                  }`}
                  title="Uczyni pozostałe aminokwasy półprzeźroczystymi, aby odsłonić ten aktywny"
                >
                  {xrayFocus ? 'Włączone' : 'Wyłączone'}
                </button>
              </div>
            </div>

            {/* Interactive SVG Rendering Matrix */}
            <svg 
              viewBox="0 0 800 500" 
              preserveAspectRatio="xMidYMid meet" 
              className="w-full h-full min-h-[350px]" 
              id="svg_canvas_renderer"
            >
              {(() => {
                const width = 800;
                const height = 500;
                const cX = width / 2;
                const cY = height / 2;

                if (viewMode === 'inside') {
                  // inside representation (zoomed atoms)
                  const projectedAtoms = activeAminoAcid.atoms.map(a => {
                    const proj = project3DTo2D(a.x * 38, a.y * 38, a.z * 38, cX, cY, 1.3);
                    return { ...a, ...proj };
                  });

                  // Sort depth axis
                  projectedAtoms.sort((a,b) => b.z - a.z);

                  return (
                    <g>
                      {(() => {
                        const p0 = project3DTo2D(0, 0, 0, cX, cY, 1.3);
                        const pX = project3DTo2D(280, 0, 0, cX, cY, 1.3);
                        const pY = project3DTo2D(0, 280, 0, cX, cY, 1.3);
                        const pZ = project3DTo2D(0, 0, 280, cX, cY, 1.3);
                        return (
                          <g opacity="0.8" className="pointer-events-none select-none">
                            <line x1={p0.x} y1={p0.y} x2={pX.x} y2={pX.y} stroke="#ef4444" strokeWidth="2" strokeDasharray="3,3" />
                            <text x={pX.x + 4} y={pX.y + 3} className="fill-red-400 font-mono text-[9px] font-bold">X</text>
                            
                            <line x1={p0.x} y1={p0.y} x2={pY.x} y2={pY.y} stroke="#10b981" strokeWidth="2" strokeDasharray="3,3" />
                            <text x={pY.x + 4} y={pY.y + 3} className="fill-emerald-400 font-mono text-[9px] font-bold">Y</text>
                            
                            <line x1={p0.x} y1={p0.y} x2={pZ.x} y2={pZ.y} stroke="#3b82f6" strokeWidth="2" strokeDasharray="3,3" />
                            <text x={pZ.x + 4} y={pZ.y + 3} className="fill-blue-400 font-mono text-[9px] font-bold">Z</text>
                          </g>
                        );
                      })()}

                      {/* Grid sferyczny 248 łatek */}
                      <circle cx={cX} cy={cY} r={120} fill="none" stroke="#1d1b32" strokeWidth="1" strokeDasharray="3,4" />
                      <circle cx={cX} cy={cY} r={180} fill="none" stroke="#0e101f" strokeWidth="1.5" strokeDasharray="1,5" />
                      <text x={cX} y={cY - 126} className="fill-indigo-500/60 font-mono text-[8px] text-center" textAnchor="middle">BIEGUN ŁATKA #1</text>
                      <text x={cX} y={cY + 138} className="fill-indigo-500/60 font-mono text-[8px] text-center" textAnchor="middle">BIEGUN ŁATKA #248</text>

                      {/* Chemical connections */}
                      {activeAminoAcid.bonds.map((bond, bIdx) => {
                        const fromAtom = projectedAtoms.find(a => a.id === bond.from);
                        const toAtom = projectedAtoms.find(a => a.id === bond.to);

                        if (!fromAtom || !toAtom) return null;
                        const isDouble = bond.type === 'double';

                        return (
                          <g key={`bond-${bIdx}`}>
                            {isDouble ? (
                              <>
                                <line 
                                  x1={fromAtom.x - 3} y1={fromAtom.y - 3} x2={toAtom.x - 3} y2={toAtom.y - 3} 
                                  stroke="#334155" strokeWidth="4.5" 
                                />
                                <line 
                                  x1={fromAtom.x + 3} y1={fromAtom.y + 3} x2={toAtom.x + 3} y2={toAtom.y + 3} 
                                  stroke="#94a3b8" strokeWidth="1.8" 
                                />
                              </>
                            ) : (
                              <line 
                                x1={fromAtom.x} y1={fromAtom.y} x2={toAtom.x} y2={toAtom.y} 
                                stroke="#1e293b" strokeWidth="5" 
                                strokeLinecap="round"
                              />
                            )}
                          </g>
                        );
                      })}

                      {/* Atom balls */}
                      {projectedAtoms.map((atom, aIdx) => {
                        const baseRadius = atom.element === 'H' ? 8 : atom.element === 'C' ? 14 : atom.element === 'O' ? 12 : 13;
                        const sphereRad = baseRadius * atom.scale;
                        const fillCol = getAtomColor(atom.element);

                        return (
                          <g key={`atom-${aIdx}`}>
                            <circle cx={atom.x} cy={atom.y} r={sphereRad + 4} fill={fillCol} opacity="0.15" />
                            <circle 
                              cx={atom.x} 
                              cy={atom.y} 
                              r={sphereRad} 
                              fill={fillCol} 
                              stroke="#000" 
                              strokeWidth="1.8" 
                            />
                            {/* reflective point */}
                            <circle cx={atom.x - sphereRad*0.3} cy={atom.y - sphereRad*0.3} r={sphereRad * 0.25} fill="#fff" opacity="0.45" />
                            <text 
                              x={atom.x} 
                              y={atom.y + 3.5} 
                              className="fill-black text-[9px] font-extrabold select-none pointer-events-none text-center font-mono"
                              textAnchor="middle"
                            >
                              {atom.element}
                            </text>
                          </g>
                        );
                      })}
                    </g>
                  );

                } else {
                  // Whole protein chain view centered around CoM (0,0,0) or Compare view
                  const views = viewMode === 'compare' 
                    ? [
                        { label: 'DETERMINISTIC ENGINE', xOffset: -200, variant: 'det' },
                        { label: 'ALPHAFOLD PDB REF', xOffset: 200, variant: 'af' }
                      ]
                    : [
                        { label: '', xOffset: 0, variant: 'det' }
                      ];

                  const focusedIdx = playbackNodeIndex !== null ? playbackNodeIndex : activeIndex;

                  return (
                    <g>
                      {views.map((v, vIdx) => {
                        const localCX = cX + v.xOffset;
                        
                        const projectedChain = centeredChain.map((c, i) => {
                          const perturb = v.variant === 'af' ? Math.sin(i * 0.8) * 45 : 0;
                          const proj = project3DTo2D(c.x + perturb, c.y + (v.variant === 'af' ? Math.cos(i) * 35 : 0), c.z + perturb, localCX, cY, v.variant === 'af' ? 0.85 : 0.9);
                          return { ...c, ...proj };
                        });

                        return (
                          <g key={'view-' + vIdx}>
                            {v.label && (
                              <text x={localCX} y={cY - 220} className="fill-zinc-500 font-mono text-[14px] font-extrabold text-center tracking-widest" textAnchor="middle">
                                {v.label}
                                {v.variant === 'af' && (
                                  <tspan x={localCX} y={cY - 200} className="fill-emerald-500 text-[10px]">LDDT SCORE: 89.4% (GOOD)</tspan>
                                )}
                              </text>
                            )}
                            
                            {/* Axis System */}
                            {(() => {
                              const p0 = project3DTo2D(0, 0, 0, localCX, cY, 0.9);
                              const pX = project3DTo2D(450, 0, 0, localCX, cY, 0.9);
                              const pY = project3DTo2D(0, 450, 0, localCX, cY, 0.9);
                              const pZ = project3DTo2D(0, 0, 450, localCX, cY, 0.9);
                              return (
                                <g opacity="0.9" className="pointer-events-none select-none">
                                  <line x1={p0.x} y1={p0.y} x2={pX.x} y2={pX.y} stroke="#ef4444" strokeWidth="2.5" strokeDasharray="4,2" />
                                  <circle cx={pX.x} cy={pX.y} r="3" fill="#ef4444" />
                                  <text x={pX.x + 6} y={pX.y + 3} className="fill-red-400 font-mono text-[10px] font-extrabold" style={{ textShadow: '0 0 4px rgba(0,0,0,0.8)' }}>X</text>
                                  
                                  <line x1={p0.x} y1={p0.y} x2={pY.x} y2={pY.y} stroke="#10b981" strokeWidth="2.5" strokeDasharray="4,2" />
                                  <circle cx={pY.x} cy={pY.y} r="3" fill="#10b981" />
                                  <text x={pY.x + 6} y={pY.y + 3} className="fill-emerald-400 font-mono text-[10px] font-extrabold" style={{ textShadow: '0 0 4px rgba(0,0,0,0.8)' }}>Y</text>
                                  
                                  <line x1={p0.x} y1={p0.y} x2={pZ.x} y2={pZ.y} stroke="#3b82f6" strokeWidth="2.5" strokeDasharray="4,2" />
                                  <circle cx={pZ.x} cy={pZ.y} r="3" fill="#3b82f6" />
                                  <text x={pZ.x + 6} y={pZ.y + 3} className="fill-blue-400 font-mono text-[10px] font-extrabold" style={{ textShadow: '0 0 4px rgba(0,0,0,0.8)' }}>Z</text>

                                  <circle cx={p0.x} cy={p0.y} r={7} fill="none" stroke="#fbbf24" strokeWidth="1.5" />
                                  <text x={p0.x + 8} y={p0.y - 8} className="fill-yellow-500 font-mono text-[7px]" opacity="0.9">CENTER OF MASS CoM (0,0,0)</text>
                                </g>
                              );
                            })()}

                            {/* Connection links */}
                            {projectedChain.map((p, idx) => {
                              if (idx === 0) return null;
                              const prev = projectedChain[idx - 1];
                              const isLinkFocused = focusedIdx === idx || focusedIdx === idx - 1;
                              const opacityVal = xrayFocus ? (isLinkFocused ? 1.0 : 0.15) : 1.0;
                              const color = v.variant === 'af' ? 'rgba(16, 185, 129, 0.5)' : 'rgba(99, 102, 241, 0.65)';
                              const beadColor = v.variant === 'af' ? '#10b981' : '#f43f5e';

                              return (
                                <g key={'lnk-'+idx} opacity={opacityVal} className="transition-opacity duration-300">
                                  <line
                                    x1={prev.x}
                                    y1={prev.y}
                                    x2={p.x}
                                    y2={p.y}
                                    stroke={color}
                                    strokeWidth="3.5"
                                    strokeLinecap="round"
                                    className="animate-bond-pulse animate-molecular-vibration"
                                  />
                                  <circle cx={(prev.x + p.x)/2} cy={(prev.y + p.y)/2} r="3" fill={beadColor} />
                                </g>
                              );
                            })}

                            {/* Golden Disulfide covalent paths */}
                            {(() => {
                              const pairs: number[][] = [];
                              projectedChain.forEach((p, idx) => {
                                if (p.node.aminoAcid.id === 'CYS' || p.node.aminoAcid.id === 'SEC') {
                                  projectedChain.forEach((p2, idx2) => {
                                    if (idx2 > idx && (p2.node.aminoAcid.id === 'CYS' || p2.node.aminoAcid.id === 'SEC')) {
                                      pairs.push([idx, idx2]);
                                    }
                                  });
                                }
                              });

                              return pairs.map(([i1, i2], pIdx) => {
                                const p1 = projectedChain[i1];
                                const p2 = projectedChain[i2];
                                const isBridgeFocused = focusedIdx === i1 || focusedIdx === i2;
                                const baseOpacity = proteinVariant === 'patient' ? 0.08 : 1.0;
                                const opacityVal = xrayFocus ? (isBridgeFocused ? 1.0 : 0.12 * baseOpacity) : baseOpacity;

                                return (
                                  <path
                                    key={'ss-bridge-'+pIdx}
                                    d={`M ${p1.x} ${p1.y} Q ${(p1.x+p2.x)/2 + 25} ${(p1.y+p2.y)/2 - 25} ${p2.x} ${p2.y}`}
                                    stroke="#eab308"
                                    strokeWidth="3"
                                    strokeDasharray="4,2"
                                    fill="none"
                                    className="animate-pulse"
                                    opacity={opacityVal}
                                  />
                                );
                              });
                            })()}

                            {/* Ball nodes for each residue */}
                            {projectedChain.map((p, idx) => {
                              const node = p.node;
                              const radius = 17 * p.scale;
                              const isActive = idx === activeIndex;
                              const isPlaying = playbackNodeIndex === idx;
                              const isNodeFocused = idx === focusedIdx;
                              const opacityVal = xrayFocus ? (isNodeFocused ? 1.0 : 0.22) : 1.0;
                              const atomColor = v.variant === 'af' ? '#064e3b' : node.aminoAcid.color;
                              const atomStroke = v.variant === 'af' ? '#10b981' : (isActive ? '#ffffff' : '#000000');
                              const textStyle = v.variant === 'af' ? 'fill-emerald-400' : 'fill-white';

                              return (
                                <g 
                                  key={'chain-nd-'+idx} 
                                  className="cursor-pointer transition-opacity duration-300" 
                                  onClick={() => selectAndSonifyNode(idx)}
                                  opacity={opacityVal}
                                >
                                  <circle cx={p.x} cy={p.y} r={radius + 8} fill={atomColor} opacity={isActive ? 0.35 : isPlaying ? 0.25 : 0} />
                                  
                                  {isPlaying && (
                                    <g>
                                      <circle 
                                        cx={p.x} 
                                        cy={p.y} 
                                        r={radius + 14} 
                                        fill="none" 
                                        stroke="#ef4444" 
                                        strokeWidth="2.5" 
                                        className="animate-pulse" 
                                        opacity="0.9" 
                                      />
                                      <circle 
                                        cx={p.x} 
                                        cy={p.y} 
                                        r={radius + 7} 
                                        fill="none" 
                                        stroke="#f43f5e" 
                                        strokeWidth="1.8" 
                                        opacity="0.8" 
                                      />
                                      <circle 
                                        cx={p.x + radius} 
                                        cy={p.y - radius} 
                                        r="5" 
                                        fill="#ef4444" 
                                        stroke="#ffffff" 
                                        strokeWidth="1.2" 
                                      />
                                    </g>
                                  )}

                                  <circle 
                                    cx={p.x} 
                                    cy={p.y} 
                                    r={radius} 
                                    fill={atomColor} 
                                    stroke={atomStroke} 
                                    strokeWidth={isActive ? '2.5' : '1.5'} 
                                  />
                                  <text
                                    x={p.x}
                                    y={p.y + 3.5}
                                    className={`${v.variant === 'af' ? 'fill-emerald-400' : 'fill-black'} font-extrabold text-[10px] font-mono text-center select-none pointer-events-none`}
                                    textAnchor="middle"
                                  >
                                    {node.aminoAcid.code1}
                                  </text>
                                  
                                  <text
                                    x={p.x}
                                    y={p.y - radius - 6}
                                    className={`${textStyle} font-mono text-[9px] text-center select-none pointer-events-none font-bold`}
                                    textAnchor="middle"
                                    opacity={isActive ? 1 : 0.6}
                                    style={{ textShadow: '1px 1px 2px #000' }}
                                  >
                                    {idx+1}.{node.aminoAcid.code3}
                                  </text>
                                </g>
                              );
                            })}
                          </g>
                        );
                      })}
                    </g>
                  );
                }
              })()}
            </svg>
          </div>

          {/* 3. THE 5 HORIZONTAL SEQUENCE SOUND LANES */}
          <section className="bg-[#030306] border-t border-zinc-900/90 p-3 shrink-0 flex flex-col justify-end" id="five_musical_tracks_subpanel">
            <div className="flex justify-between items-center mb-2 px-1">
              <div className="flex items-center gap-1.5 leading-none">
                <Music className="w-4 h-4 text-emerald-500" />
                <span className="text-[11px] font-mono font-extrabold uppercase text-white tracking-widest">Audio Sequence Track Lanes (Horizontal DAW view):</span>
              </div>
              
              {/* DYNAMIC PLAYBACK SPEED (TEMPO) MANUAL OVERRIDES */}
              <div className="flex items-center gap-2 bg-black/80 border border-zinc-850 rounded-lg px-2 py-1 font-mono text-[9px] select-none shadow-md">
                <span className="text-zinc-500 font-bold uppercase text-[8px] tracking-wider">Tempo Multiplier:</span>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setTempoMultiplier(p => Math.max(p - 0.25, 0.25))}
                    className="w-4.5 h-4.5 bg-zinc-900 border border-zinc-750 hover:bg-zinc-800 text-white rounded font-extrabold cursor-pointer flex items-center justify-center transition"
                    title="Slower playback tempo (-)"
                  >
                    -
                  </button>
                  <span className="text-amber-500 font-extrabold w-11 text-center text-[10px]">{tempoMultiplier.toFixed(2)}x</span>
                  <button 
                    onClick={() => setTempoMultiplier(p => Math.min(p + 0.25, 3.0))}
                    className="w-4.5 h-4.5 bg-zinc-900 border border-zinc-750 hover:bg-zinc-800 text-white rounded font-extrabold cursor-pointer flex items-center justify-center transition"
                    title="Faster playback tempo (+)"
                  >
                    +
                  </button>
                  <button
                    onClick={() => setTempoMultiplier(1.0)}
                    disabled={tempoMultiplier === 1.0}
                    className="bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 hover:text-white disabled:opacity-30 disabled:pointer-events-none px-1.5 py-0.5 rounded text-[8px] uppercase cursor-pointer transition text-zinc-400 font-bold ml-1"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>

            {/* Stack of horizontal lanes */}
            <div className="space-y-1.5 text-[9.5px] font-mono" id="daw_tracks_lanes_stack">
              
              {/* LANE 1 */}
              <div className="flex items-center gap-2.5 bg-black border border-zinc-90 w-full p-1.5 rounded" id="lane_1">
                <div className="w-[180px] shrink-0 leading-tight">
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    <span>TRACK A: Peptide Bonds</span>
                  </div>
                  <p className="text-[8px] text-zinc-500 leading-none mt-0.5">Main structural chain with h-moll separators.</p>
                </div>
                {/* Horizontal timeline walk preview */}
                <div className="flex-1 flex items-center gap-0.5 bg-zinc-950/60 p-1 rounded select-none relative h-12 overflow-hidden w-full">
                  {renderEkgBackground(
                    proteinChain.map(n => n.torsionAngle), 
                    1, 
                    'rgba(99, 102, 241, 0.45)'
                  )}
                  {/* RED SWEEP LINE */}
                  {activePlaybackTrack === 1 && playbackNodeIndex !== null && (
                    <div 
                      className="absolute inset-y-0 w-[2.5px] bg-red-500 shadow-[0_0_8px_#ef4444] z-20 pointer-events-none transition-all duration-300 ease-out"
                      style={{
                        left: `${((playbackNodeIndex + 0.5) / (proteinChain.length || 1)) * 100}%`
                      }}
                    />
                  )}
                  {proteinChain.map((node, i) => {
                    const isCurrent = playbackNodeIndex === i && activePlaybackTrack === 1;
                    return (
                      <div 
                        key={i} 
                        className={`flex-1 min-w-[12px] h-9 rounded border transition relative flex flex-col justify-center items-center leading-none select-none text-center ${
                          isCurrent 
                            ? 'bg-indigo-600 border-indigo-400 text-white font-extrabold shadow-[0_0_8px_rgba(99, 102, 241, 0.5)] z-10 scale-[1.03]' 
                            : 'bg-zinc-900/40 border-zinc-850 text-zinc-400'
                        }`}
                        title={`${i+1}. ${node.aminoAcid.code3}`}
                      >
                        <span className="relative z-10 text-[8px] font-mono leading-none tracking-tighter">
                          {showFullText ? (
                            `${node.aminoAcid.code3}`
                          ) : showShortText ? (
                            `${node.aminoAcid.code1}`
                          ) : (
                            ""
                          )}
                        </span>
                        {showFullText && (
                          <span className="text-[6px] text-zinc-500 leading-none mt-0.5 scale-90 block">
                            p:{node.toPatch}
                          </span>
                        )}
                        {!showFullText && !showShortText && (
                          <span className="w-2 h-2 rounded-full block border border-black/40" style={{ backgroundColor: node.aminoAcid.color }} />
                        )}
                      </div>
                    );
                  })}
                </div>
                <button
                  onClick={() => playSequenceTrack(1)}
                  className={`px-3 py-1 text-[9px] rounded font-bold cursor-pointer border shrink-0 transition ${
                    activePlaybackTrack === 1 ? 'bg-red-950 text-red-400 border-red-800' : 'bg-indigo-950/40 border-indigo-800 text-indigo-300 hover:bg-indigo-900'
                  }`}
                >
                  {activePlaybackTrack === 1 ? 'Stop' : 'Play'}
                </button>
              </div>

              {/* LANE 2 */}
              <div className="flex items-center gap-2.5 bg-black border border-zinc-90 w-full p-1.5 rounded" id="lane_2">
                <div className="w-[180px] shrink-0 leading-tight">
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span>TRACK B: Horizontal Coaxial Scan</span>
                  </div>
                  <p className="text-[8px] text-zinc-500 leading-none mt-0.5">Scan from y_min to y_max around the center of mass.</p>
                </div>
                <div className="flex-1 flex items-center gap-0.5 bg-zinc-950/60 p-1 rounded select-none relative h-12 overflow-hidden w-full">
                  {(() => {
                    const scanSorted = [...centeredChain];
                    scanSorted.sort((a, b) => a.y - b.y);
                    const activeDisplayIdx = scanSorted.findIndex(item => item.node.id === (playbackNodeIndex !== null ? proteinChain[playbackNodeIndex]?.id : null));

                    return (
                      <>
                        {renderEkgBackground(
                          scanSorted.map(item => item.y), 
                          2, 
                          'rgba(16, 185, 129, 0.45)'
                        )}
                        {/* RED SWEEP LINE */}
                        {activePlaybackTrack === 2 && activeDisplayIdx !== -1 && (
                          <div 
                            className="absolute inset-y-0 w-[2.5px] bg-red-500 shadow-[0_0_8px_#ef4444] z-20 pointer-events-none transition-all duration-300 ease-out"
                            style={{
                              left: `${((activeDisplayIdx + 0.5) / (scanSorted.length || 1)) * 100}%`
                            }}
                          />
                        )}
                        {scanSorted.map((item, i) => {
                          const idx = centeredChain.findIndex(p => p.node.id === item.node.id);
                          const isCurrent = playbackNodeIndex === idx && activePlaybackTrack === 2;
                          return (
                            <div 
                              key={i} 
                              className={`flex-1 min-w-[12px] h-9 rounded border transition relative flex flex-col justify-center items-center leading-none select-none text-center ${
                                isCurrent 
                                  ? 'bg-emerald-600 border-emerald-400 text-white font-extrabold shadow-[0_0_8px_rgba(16,185,129,0.5)] z-10 scale-[1.03]' 
                                  : 'bg-zinc-900/40 border-zinc-850 text-zinc-500'
                              }`}
                              title={`${idx+1}. ${item.node.aminoAcid.code3} (y:${Math.round(item.y)})`}
                            >
                              <span className="relative z-10 text-[8px] font-mono leading-none tracking-tighter">
                                {showFullText ? (
                                  `${item.node.aminoAcid.code3}`
                                ) : showShortText ? (
                                  `${item.node.aminoAcid.code1}`
                                ) : (
                                  ""
                                )}
                              </span>
                              {showFullText && (
                                <span className="text-[5.5px] text-zinc-500 leading-none mt-0.5 scale-90 block">
                                  #{idx+1}
                                </span>
                              )}
                              {!showFullText && !showShortText && (
                                <span className="w-2 h-2 rounded-full block border border-black/40" style={{ backgroundColor: item.node.aminoAcid.color }} />
                              )}
                            </div>
                          );
                        })}
                      </>
                    );
                  })()}
                </div>
                <button
                  onClick={() => playSequenceTrack(2)}
                  className={`px-3 py-1 text-[9px] rounded font-bold cursor-pointer border shrink-0 transition ${
                    activePlaybackTrack === 2 ? 'bg-red-950 text-red-400 border-red-800' : 'bg-emerald-900/20 border-emerald-800 text-emerald-400 hover:bg-emerald-900'
                  }`}
                >
                  {activePlaybackTrack === 2 ? 'Stop' : 'Play'}
                </button>
              </div>

              {/* LANE 3 */}
              <div className="flex items-center gap-2.5 bg-black border border-zinc-90 w-full p-1.5 rounded" id="lane_3">
                <div className="w-[180px] shrink-0 leading-tight">
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                    <span>TRACK C: Vertical Axial Scan</span>
                  </div>
                  <p className="text-[8px] text-zinc-500 leading-none mt-0.5">Scan from front to back (Z-axis) in 3D projection.</p>
                </div>
                <div className="flex-1 flex items-center gap-0.5 bg-zinc-950/60 p-1 rounded select-none relative h-12 overflow-hidden w-full">
                  {(() => {
                    const scanSorted = [...centeredChain];
                    scanSorted.sort((a, b) => a.z - b.z);
                    const activeDisplayIdx = scanSorted.findIndex(item => item.node.id === (playbackNodeIndex !== null ? proteinChain[playbackNodeIndex]?.id : null));

                    return (
                      <>
                        {renderEkgBackground(
                          scanSorted.map(item => item.z), 
                          3, 
                          'rgba(234, 179, 8, 0.45)'
                        )}
                        {/* RED SWEEP LINE */}
                        {activePlaybackTrack === 3 && activeDisplayIdx !== -1 && (
                          <div 
                            className="absolute inset-y-0 w-[2.5px] bg-red-500 shadow-[0_0_8px_#ef4444] z-20 pointer-events-none transition-all duration-300 ease-out"
                            style={{
                              left: `${((activeDisplayIdx + 0.5) / (scanSorted.length || 1)) * 100}%`
                            }}
                          />
                        )}
                        {scanSorted.map((item, i) => {
                          const idx = centeredChain.findIndex(p => p.node.id === item.node.id);
                          const isCurrent = playbackNodeIndex === idx && activePlaybackTrack === 3;
                          return (
                            <div 
                              key={i} 
                              className={`flex-1 min-w-[12px] h-9 rounded border transition relative flex flex-col justify-center items-center leading-none select-none text-center ${
                                isCurrent 
                                  ? 'bg-yellow-600 border-yellow-400 text-white font-extrabold shadow-[0_0_8px_rgba(234,179,8,0.5)] z-10 scale-[1.03]' 
                                  : 'bg-zinc-900/40 border-zinc-850 text-zinc-500'
                              }`}
                              title={`${idx+1}. ${item.node.aminoAcid.code3} (z:${Math.round(item.z)})`}
                            >
                              <span className="relative z-10 text-[8px] font-mono leading-none tracking-tighter">
                                {showFullText ? (
                                  `${item.node.aminoAcid.code3}`
                                ) : showShortText ? (
                                  `${item.node.aminoAcid.code1}`
                                ) : (
                                  ""
                                )}
                              </span>
                              {showFullText && (
                                <span className="text-[5.5px] text-zinc-500 leading-none mt-0.5 scale-90 block">
                                  #{idx+1}
                                </span>
                              )}
                              {!showFullText && !showShortText && (
                                <span className="w-2 h-2 rounded-full block border border-black/40" style={{ backgroundColor: item.node.aminoAcid.color }} />
                              )}
                            </div>
                          );
                        })}
                      </>
                    );
                  })()}
                </div>
                <button
                  onClick={() => playSequenceTrack(3)}
                  className={`px-3 py-1 text-[9px] rounded font-bold cursor-pointer border shrink-0 transition ${
                    activePlaybackTrack === 3 ? 'bg-red-950 text-red-400 border-red-800' : 'bg-yellow-900/10 border-yellow-800 text-yellow-500 hover:bg-yellow-900'
                  }`}
                >
                  {activePlaybackTrack === 3 ? 'Stop' : 'Play'}
                </button>
              </div>

              {/* LANE 4 */}
              <div className="flex items-center gap-2.5 bg-black border border-zinc-90 w-full p-1.5 rounded" id="lane_4">
                <div className="w-[180px] shrink-0 leading-tight">
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-500" />
                    <span>TRACK D: Side Chain Resonance</span>
                  </div>
                  <p className="text-[8px] text-zinc-500 leading-none mt-0.5">Resonance based on Van der Waals volume & side chain hydrophobicity.</p>
                </div>
                <div className="flex-1 flex items-center gap-0.5 bg-zinc-950/60 p-1 rounded select-none relative h-12 overflow-hidden w-full">
                  {renderEkgBackground(
                    proteinChain.map(n => n.aminoAcid.vanDerWaals), 
                    4, 
                    'rgba(236, 72, 153, 0.45)'
                  )}
                  {/* RED SWEEP LINE */}
                  {activePlaybackTrack === 4 && playbackNodeIndex !== null && (
                    <div 
                      className="absolute inset-y-0 w-[2.5px] bg-red-500 shadow-[0_0_8px_#ef4444] z-20 pointer-events-none transition-all duration-300 ease-out"
                      style={{
                        left: `${((playbackNodeIndex + 0.5) / (proteinChain.length || 1)) * 100}%`
                      }}
                    />
                  )}
                  {proteinChain.map((node, i) => {
                    const isCurrent = playbackNodeIndex === i && activePlaybackTrack === 4;
                    const isMutation = proteinVariant === 'patient' && node.aminoAcid.id === 'ALA' && (i === 6 || i === 10 || i === 19);
                    return (
                      <div 
                        key={i} 
                        className={`flex-1 min-w-[12px] h-9 rounded border transition relative flex flex-col justify-center items-center leading-none select-none text-center ${
                          isCurrent 
                            ? 'bg-pink-600 border-pink-400 text-white font-extrabold shadow-[0_0_8px_rgba(236,72,153,0.5)] z-10 scale-[1.03]' 
                            : isMutation
                            ? 'bg-red-950/40 border-red-900 text-red-500 font-extrabold line-through'
                            : 'bg-zinc-900/40 border-zinc-850 text-zinc-500'
                        }`}
                        title={isMutation ? "MUTATION: Alanine detected instead of Cysteine!" : `${i+1}. ${node.aminoAcid.code3}`}
                      >
                        <span className="relative z-10 text-[8px] font-mono leading-none tracking-tighter">
                          {showFullText ? (
                            `${node.aminoAcid.code3}`
                          ) : showShortText ? (
                            `${node.aminoAcid.code1}`
                          ) : (
                            ""
                          )}
                        </span>
                        {showFullText && (
                          <span className="text-[6px] text-zinc-500 leading-none mt-0.5 scale-90 block">
                            v:{node.aminoAcid.vanDerWaals}
                          </span>
                        )}
                        {!showFullText && !showShortText && (
                          <span className="w-2 h-2 rounded-full block border border-black/40" style={{ backgroundColor: node.aminoAcid.color }} />
                        )}
                      </div>
                    );
                  })}
                </div>
                <button
                  onClick={() => playSequenceTrack(4)}
                  className={`px-3 py-1 text-[9px] rounded font-bold cursor-pointer border shrink-0 transition ${
                    activePlaybackTrack === 4 ? 'bg-red-950 text-red-400 border-red-800' : 'bg-pink-900/10 border-pink-800 text-pink-400 hover:bg-pink-900'
                  }`}
                >
                  {activePlaybackTrack === 4 ? 'Stop' : 'Play'}
                </button>
              </div>

              {/* LANE 5 */}
              <div className="flex items-center gap-2.5 bg-black border border-zinc-90 w-full p-1.5 rounded" id="lane_5">
                <div className="w-[180px] shrink-0 leading-tight">
                  <div className="flex items-center gap-1.5 text-white font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
                    <span>TRACK E: Disulfide Bridges</span>
                  </div>
                  <p className="text-[8px] text-zinc-500 leading-none mt-0.5">Covalent S-S disulfide bridge markers.</p>
                </div>
                <div className="flex-1 flex items-center gap-0.5 bg-zinc-950/60 p-1 rounded select-none relative h-12 overflow-hidden w-full">
                  {renderEkgBackground(
                    proteinChain.map(n => (n.aminoAcid.id === 'CYS' || n.aminoAcid.id === 'SEC') ? 80 : 15), 
                    5, 
                    'rgba(20, 184, 166, 0.45)'
                  )}
                  {/* RED SWEEP LINE */}
                  {activePlaybackTrack === 5 && playbackNodeIndex !== null && (
                    <div 
                      className="absolute inset-y-0 w-[2.5px] bg-red-500 shadow-[0_0_8px_#ef4444] z-20 pointer-events-none transition-all duration-300 ease-out"
                      style={{
                        left: `${((playbackNodeIndex + 0.5) / (proteinChain.length || 1)) * 100}%`
                      }}
                    />
                  )}
                  {proteinChain.map((node, i) => {
                    const isCurrent = playbackNodeIndex === i && activePlaybackTrack === 5;
                    const isBridge = node.aminoAcid.id === 'CYS' || node.aminoAcid.id === 'SEC';
                    return (
                      <div 
                        key={i} 
                        className={`flex-1 min-w-[12px] h-9 rounded border transition relative flex flex-col justify-center items-center leading-none select-none text-center ${
                          isCurrent 
                            ? 'bg-teal-600 border-teal-400 text-white font-extrabold shadow-[0_0_8px_rgba(20,184,166,0.5)] z-10 scale-[1.03]' 
                            : isBridge && proteinVariant === 'healthy'
                            ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400 font-bold'
                            : isBridge && proteinVariant === 'patient'
                            ? 'bg-zinc-900 border-zinc-800 text-zinc-600/30 line-through opacity-40'
                            : 'bg-zinc-950 border-transparent text-zinc-700'
                        }`}
                        title={`${i+1}. ${node.aminoAcid.code3} ${isBridge ? '(S-S Bond)' : ''}`}
                      >
                        <span className="relative z-10 text-[8px] font-mono leading-none tracking-tighter">
                          {showFullText ? (
                            `${node.aminoAcid.code3}`
                          ) : showShortText ? (
                            `${node.aminoAcid.code1}`
                          ) : (
                            ""
                          )}
                        </span>
                        {showFullText && isBridge && (
                          <span className="text-[6px] text-yellow-400 font-bold leading-none mt-0.5 block scale-90">
                            S-S
                          </span>
                        )}
                        {!showFullText && !showShortText && (
                          <span className="w-2 h-2 rounded-full block border border-black/40" style={{ backgroundColor: node.aminoAcid.color }} />
                        )}
                      </div>
                    );
                  })}
                </div>
                <button
                  onClick={() => playSequenceTrack(5)}
                  className={`px-3 py-1 text-[9px] rounded font-bold cursor-pointer border shrink-0 transition ${
                    activePlaybackTrack === 5 ? 'bg-red-950 text-red-400 border-red-800' : 'bg-teal-900/20 border-teal-850 text-teal-400 hover:bg-teal-900'
                  }`}
                >
                  {activePlaybackTrack === 5 ? 'Stop' : 'Play'}
                </button>
              </div>

            </div>
          </section>

        </main>

        {/* PANEL RIGHT: DETAILED COHESION STATS & ANGLES COUPLING */}
        <aside className="col-span-2 bg-[#020204] border-l border-zinc-900 px-3 py-2.5 overflow-y-auto space-y-4 font-mono select-none" id="panel_right_analysis">
          
          <div className="border-b border-zinc-900 pb-2">
            <span className="text-[8px] tracking-widest text-zinc-500 uppercase font-bold block">Geometry Status</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-[11px] font-bold text-zinc-100">Chain Length:</span>
              <span className="text-xs font-extrabold text-indigo-400">{proteinChain.length} residues</span>
            </div>
            <div className="flex items-center justify-between mt-1 text-[10px]">
              <span className="text-zinc-500">S-S Bridges:</span>
              <span className={`font-bold ${proteinVariant === 'healthy' ? 'text-amber-500' : 'text-zinc-700'}`}>
                {proteinVariant === 'healthy' ? 'Healthy (3 active)' : '0 (None - CYS mutation!)'}
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <span className="text-[9px] text-[#71717a] block uppercase font-bold">Cohesion Energy:</span>
              <div className={`text-xl font-black font-mono mt-0.5 tracking-tight ${energyLevel < -50 ? 'text-emerald-400' : 'text-red-500'}`}>
                {energyLevel} kcal/mol
              </div>
              <p className="text-[8px] text-zinc-500 leading-tight mt-1">
                A lower negative energy level indicates a more stable deterministic protein fold configuration.
              </p>
            </div>

            <div className="border-t border-zinc-900 pt-3 space-y-1 text-[10px]">
              <span className="text-[8.5px] text-zinc-500 block font-bold">ACTIVE SNAPLOCK CONNECTION:</span>
              <div className="bg-slate-950 border border-zinc-900 p-2 rounded space-y-1 text-slate-300">
                <p>• Preceeding patch: <span className="text-white font-extrabold">#{activeChainNode.fromPatch}</span></p>
                <p>• Attachment patch: <span className="text-white font-extrabold">#{activeChainNode.toPatch}</span></p>
                <p>• Torsion Angle: <span className="text-amber-500 font-extrabold">{activeChainNode.torsionAngle}°</span></p>
              </div>
            </div>

            <div className="border-t border-zinc-900 pt-3 space-y-2">
              <span className="text-[9px] text-zinc-500 block uppercase font-bold">Determination Engine</span>

              <button 
                onClick={runFoldingProcess}
                disabled={isFolding}
                className="w-full py-2 bg-indigo-950 hover:bg-indigo-900 disabled:opacity-45 text-indigo-300 hover:text-white border border-indigo-800 rounded font-bold text-[10.5px] text-center cursor-pointer flex items-center justify-center gap-1.5 transition select-none"
              >
                <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
                <span>Fold Deterministically</span>
              </button>

              {isFolding && (
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] text-zinc-400">
                    <span>Folding kinetics simulation...</span>
                    <span>{foldingProgress}%</span>
                  </div>
                  <div className="h-1 bg-zinc-900 rounded overflow-hidden">
                    <div className="h-full bg-indigo-500 transition-all duration-75" style={{ width: `${foldingProgress}%` }} />
                  </div>
                </div>
              )}
            </div>

            <div className="border-t border-zinc-900 pt-3 text-[9.5px] leading-relaxed text-zinc-500">
              <span className="text-[#8e8e9f] font-bold block mb-1">Laws of Folding Determinism:</span>
              <p>1. Hydrophobic residues fold inwards escaping ambient aquatic environments toward the Center of Mass (CoM).</p>
              <p className="mt-1">2. Cysteine junctions form physical covalent bridges dynamically when local coordinates align within bounds.</p>
              <p className="mt-1">3. The Snaplock mechanistics lock rotation physically, preventing gradual spatial coordinate drift.</p>
            </div>
          </div>
        </aside>

      </div>

      {/* 3. WAREHOUSE OF 21 AMINO ACIDS (Clicking one previews it in sphere bounds) */}
      <footer className="bg-[#010103] border-t border-zinc-900 px-5 py-3 shrink-0 z-20" id="panel_warehouse">
        <div className="flex justify-between items-center mb-2 px-1 text-[10.5px] font-mono leading-none">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
            <h3 className="font-extrabold uppercase text-white tracking-widest">21 AMINO ACIDS WAREHOUSE (Atoms aligned vertically to absolute poles):</h3>
          </div>
          <p className="text-[9.5px] text-zinc-500 italic font-medium">Click any amino acid residue to inspect its 3D atomic model and launch chemical specs onto the patching sphere.</p>
        </div>

        {/* Horizontal row of amino acids */}
        <div className="grid grid-cols-7 sm:grid-cols-11 md:grid-cols-21 gap-1.5" id="warehouse_acid_list">
          {AMINO_ACIDS.map((acid) => {
            const isSelected = selectedWarehouseAcid?.id === acid.id;
            return (
              <button
                key={acid.id}
                onClick={() => {
                  setSelectedWarehouseAcid(acid);
                  setViewMode('inside');
                  // update the active index block if it has a match in protein chain to quickly inspect
                  const idxInChain = proteinChain.findIndex(p => p.aminoAcid.id === acid.id);
                  if (idxInChain >= 0) {
                    selectAndSonifyNode(idxInChain);
                  } else {
                    playChord(Math.abs(Math.round(acid.mass)) % 10, 0.45);
                  }
                }}
                className={`p-1.5 rounded border text-left flex flex-col justify-between cursor-pointer transition-all ${
                  isSelected 
                    ? 'bg-indigo-950 border-indigo-600 ring-1 ring-indigo-500/50 scale-[1.03]' 
                    : 'bg-black border-zinc-900/80 hover:bg-[#07070d] hover:border-zinc-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] font-black font-mono text-white leading-none">{acid.code3}</span>
                  <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: acid.color }} />
                </div>
                <div className="mt-1 leading-none text-ellipsis overflow-hidden whitespace-nowrap">
                  <span className="text-[8px] font-mono text-zinc-500 truncate block">{acid.nameEn}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected warehouse acid details banner */}
        {selectedWarehouseAcid && (
          <div className="mt-2.5 bg-black border border-zinc-900 p-2 rounded-lg flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-mono leading-none">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedWarehouseAcid.color }} />
              <div>
                <span className="text-zinc-500 uppercase">ACTIVE RESIDUE DETAIL:</span>{' '}
                <span className="text-white font-extrabold text-xs">{selectedWarehouseAcid.nameEn} ({selectedWarehouseAcid.code3})</span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-y-2 md:gap-x-6 text-zinc-400">
              <p>Molar Mass: <span className="text-[#fff] font-bold">{selectedWarehouseAcid.mass} g/mol</span></p>
              <p>Van der Waals Volume: <span className="text-[#fff] font-bold">{selectedWarehouseAcid.vanDerWaals} volumes</span></p>
              <p>Ramachandran Angles: <span className="text-amber-500 font-bold">phi: {selectedWarehouseAcid.ramachandranPhi || -60}°, psi: {selectedWarehouseAcid.ramachandranPsi || -45}°</span></p>
              <p>Hydrophobicity: <span className="text-teal-400 font-bold">{selectedWarehouseAcid.hydrophobicity} index</span></p>
              <p>Chemical Class: <span className="text-indigo-400 font-bold uppercase">{selectedWarehouseAcid.type}</span></p>
            </div>

            <div className="text-right leading-relaxed text-zinc-600 text-[9px]">
              *Spherically locked with respect to the Y axis connecting patch #1 at the North Pole and patch #248 at the South Pole.
            </div>
          </div>
        )}
      </footer>

      {/* MODUŁ BIOINFORMATYCZNY: EKSPORT PDB / CIF • WALIDACJA AI (RMSD, TM-SCORE, RAMACHANDRAN DLA KIMI K3) */}
      <BioinformaticsModal
        isOpen={isBioinformaticsModalOpen}
        onClose={() => setIsBioinformaticsModalOpen(false)}
        proteinChain={proteinChain}
        centeredChain={centeredChain}
        cohesiveEnergy={energyLevel}
      />

    </div>
  );
}
